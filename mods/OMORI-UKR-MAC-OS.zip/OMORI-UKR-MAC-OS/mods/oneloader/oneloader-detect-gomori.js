if(!$modLoader.overlayFS){alert("The 77Loader assistant mod will not work with GOMORI. Please uninstall this mod or switch from GOMORI to 77Loader");}
