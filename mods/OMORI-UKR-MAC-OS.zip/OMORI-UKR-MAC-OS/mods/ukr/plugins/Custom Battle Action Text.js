//=============================================================================
// TDS Custom Battle Action Text
// Version: 1.0
//=============================================================================
// Add to Imported List
var Imported = Imported || {} ; Imported.TDS_CustomBattleActionText = true;
// Initialize Alias Object
var _TDS_ = _TDS_ || {} ; _TDS_.CustomBattleActionText = _TDS_.CustomBattleActionText || {};
//=============================================================================
 /*:
 * @plugindesc
 * This plugins allows you to set customized messages for actions.
 *
 * @author TDS
 */
//=============================================================================


//=============================================================================
// ** Window_BattleLog
//-----------------------------------------------------------------------------
// The window for displaying battle progress. No frame is displayed, but it is
// handled as a window for convenience.
//=============================================================================
// Alias Listing
//=============================================================================
_TDS_.CustomBattleActionText.Window_BattleLog_displayAction         = Window_BattleLog.prototype.displayAction;
_TDS_.CustomBattleActionText.Window_BattleLog_displayActionResults  = Window_BattleLog.prototype.displayActionResults;
//=============================================================================
// * Make Custom Action Text
//=============================================================================
Window_BattleLog.prototype.makeCustomActionText = function(subject, target, item) {
  var user          = subject;
  var result        = target.result();
  var hit           = result.isHit();
  var success       = result.success;
  var critical      = result.critical;
  var missed        = result.missed;
  var evaded        = result.evaded;
  var hpDam         = result.hpDamage;
  var mpDam         = result.mpDamage;
  var tpDam         = result.tpDamage;
  var addedStates   = result.addedStates;
  var removedStates = result.removedStates;
  var strongHit     = result.elementStrong;
  var weakHit       = result.elementWeak;
  var text = '';
  var type = item.meta.BattleLogType.toUpperCase();
  var switches = $gameSwitches;
  var unitLowestIndex = target.friendsUnit().getLowestIndexMember();

	// Get actor names
	['rodovyi', 'davalnyi', 'znakhidnyi', 'orudnyi', 'mistsevyi', 'klychnyi'].forEach(function(suffix) {
		var originalMethod = 'originalname_' + suffix;
		var nameMethod = 'name_' + suffix;
		Game_Actor.prototype[originalMethod] = function() {
			var actorName = this.actor()['name_' + suffix];
			return actorName !== undefined ? actorName : target.name();
		};
		Game_Actor.prototype[nameMethod] = function() {
			return this[originalMethod]();
		};
	});


	// Get target names
	['rodovyi', 'davalnyi', 'znakhidnyi', 'orudnyi', 'mistsevyi', 'klychnyi'].forEach(function(suffix) {
		var originalMethod = 'originalname_' + suffix;
		var nameMethod = 'name_' + suffix;
		Game_Enemy.prototype[originalMethod] = function() {
			var enemyName = this.enemy()['name_' + suffix];
			return enemyName !== undefined ? enemyName : target.name();
		};
		Game_Enemy.prototype[nameMethod] = function() {
			return this[originalMethod]();
		};
	});

  function parseNoEffectEmotion(tname, em) {
    if(em.toLowerCase().contains("afraid")) {
      if(tname === $gameActors.actor(1).name()) {return "ОМОРІ не може бути У ЖАХУ!\r\n"}
      return target.name() + " не може бути У ЖАХУ!\r\n";
    }
    let finalString = `${tname} не може відчувати ${em}`;
    if(finalString.length >= 40) {
      let voinIndex = 0;
      for(let i = 40; i >= 0; i--) {
        if(finalString[i] === " ") {
          voinIndex = i;
          break;
        }
      }
      finalString = [finalString.slice(0, voinIndex).trim(), "\r\n", finalString.slice(voinIndex).trimLeft()].join('')
    }
    return finalString;
  }

  function parseNoStateChange(tname,stat,hl) {
    let noStateChangeText = `${stat} ${tname} не може\r\nбути ${hl}`; // TARGET NAME - STAT - HIGHER/LOWER
    return noStateChangeText
  }

  // Type case
//OMORI//
if (hpDam != 0) {
  var hpDamageText = target.name() + ' зазнає ' + hpDam + ' шкоди!';
  if (strongHit) {
    hpDamageText = '... Це була разюча атака!\r\n' + hpDamageText;
  } else if (weakHit) {
    hpDamageText = '... Це була безглузда атака.\r\n' + hpDamageText;
  }
} else if (result.isHit() === true) {
  var hpDamageText = "Атака " + user.name_rodovyi() + " не нанесла шкоди.";
} else {
  var hpDamageText = "Атака " + user.name_rodovyi() + " промайнула повз!";
}

if (critical) {
    hpDamageText = 'УДАР ПРИЙШОВСЯ ПРЯМО В СЕРЦЕ!\r\n' + hpDamageText;
}

if (mpDam > 0) {
  var mpDamageText = target.name() + ' втрачає ' + mpDam + ' СОКУ...';
  hpDamageText = hpDamageText + "\r\n" + mpDamageText;
} else {
  var mpDamageText = '';
}

  switch (type) {
  case 'BLANK': // ATTACK
    text = '...';
    break;

  case 'ATTACK': // ATTACK
    text = user.name() + ' атакує ' + target.name_znakhidnyi() + '!\r\n';
    text += hpDamageText;
    break;

  case 'MULTIHIT':
    text = user.name() + "завдає разючого удару!\r\n";
    break;

  case 'OBSERVE': // OBSERVE
    text = user.name() + ' зосереджує погляд та спостерігає.\r\n';
    text += target.name_znakhidnyi() + '!';
    break;

  case 'OBSERVE TARGET': // OBSERVE TARGET
    //text = user.name() + " спостерігає за " + target.name_orudnyi() + ".\r\n";
    text = target.name() + ' зупинив погляд на\r\n';
    text += user.name_mistsevyi() + '!';
    break;

  case 'OBSERVE ALL': // OBSERVE TARGET
    //text = user.name() + " спостерігає за " + target.name_orudnyi() + ".\r\n";
    text = user.name() + ' зосереджує погляд та спостерігає.\r\n';
    text += target.name_znakhidnyi() + '!';
    text = target.name() + ' затримує погляд на всіх';
    break;

  case 'SAD POEM':  // SAD POEM
    text = user.name() + ' декламує сумного вірша.\r\n';
    if(!target._noEffectMessage) {
      if(target.isStateAffected(12)) {text += target.name() + ' у БЕЗНАДІЇ...';}
      else if(target.isStateAffected(11)) {text += target.name() + ' в ЖУРБІ...';}
      else if(target.isStateAffected(10)) {text += target.name() + ' відчуває СУМ.';}
    }
    else {text += parseNoEffectEmotion(target.name(), "стає СУМНІШЕ!")}
    break;

  case 'STAB': // STAB
    text = user.name() + ' штрикає ' + target.name_znakhidnyi() + '.\r\n';
    text += hpDamageText;
    break;

  case 'TRICK':  // TRICK
    text = user.name() + ' заплутує ' + target.name_znakhidnyi() + '.\r\n';
    if(target.isEmotionAffected("happy")) {
      if(!target._noStateMessage) {text += 'ШВИДКІСТЬ ' + target.name_rodovyi() + ' знизилася!\r\n';}
      else {text += parseNoStateChange("ШВИДКІСТЬ", target.name_rodovyi(), "стала нижче!\r\n")}
    }
    text += hpDamageText;
    break;

  case 'SHUN': // SHUN
    text = user.name() + ' уникає ' + target.name_znakhidnyi() + '.\r\n';
    if(target.isEmotionAffected("sad")) {
      if(!target._noStateMessage) {text += 'ЗАХИСТ ' + target.name_rodovyi() + ' знизився.\r\n';}
      else {text += parseNoStateChange("ЗАХИСТ", target.name_rodovyi(), "став нижче!\r\n")}
    }
    text += hpDamageText;
    break;

  case 'MOCK': // MOCK
    text = user.name() + ' глузує з ' + target.name_rodovyi() + '.\r\n';
    text += hpDamageText;
    break;

  case 'HACKAWAY':  // Hack Away
    text = user.name() + ' дико розмахує ножем!';
    break;

  case 'PICK POCKET': //Pick Pocket
    text = user.name() + ' намагається взяти предмет!\r\n';
    text += 'з ' + target.name_rodovyi();
    break;

  case 'BREAD SLICE': //Bread Slice
    text = user.name() + ' шматує ' + target.name_znakhidnyi() + '!\r\n';
    text += hpDamageText;
    break;

  case 'HIDE': // Hide
    text = user.name() + ' зливається з оточенням...';
    break;

  case 'QUICK ATTACK': // Quick Attack
    text = user.name() + ' кидається на ' + target.name_znakhidnyi() + '!\r\n';
    text += hpDamageText;
    break;

  case 'EXPLOIT HAPPY': //Exploit Happy
    text = user.name() + ' використовує щастя ' + target.name_rodovyi() + '!\r\n';
    text += hpDamageText;
    break;

  case 'EXPLOIT SAD': // Exploit Sad
    text = user.name() + ' використовує сум ' + target.name_rodovyi() + '!\r\n';
    text += hpDamageText;
    break;

  case 'EXPLOIT ANGRY': // Exploit Angry
    text = user.name() + ' використовує злість ' + target.name_rodovyi() + '!\r\n';
    text += hpDamageText;
    break;

  case 'EXPLOIT EMOTION': // Exploit Emotion
    text = user.name() + " використовує ЕМОЦІЇ " + target.name_rodovyi() ;
    if(text.length >= 34) {
      text = user.name() + ' використовує ЕМОЦІЇ ' + target.name_rodovyi() + '!\r\n';
    }
    else {text += "!\r\n"}
    text += hpDamageText;
    break;

  case 'FINAL STRIKE': // Final Strike
    text = user.name() + ' вивільняє свою ультимативну здібність!';
    break;

  case 'TRUTH': // PAINFUL TRUTH
    text = user.name() + ' шепоче щось до\r\n';
    text += target.name_rodovyi() + '.\r\n';
    text += hpDamageText + "\r\n";
    if(!target._noEffectMessage) {
      text += target.name() + " відчуває СУМ.\r\n";
    }
    else {text += parseNoEffectEmotion(target.name(), "стає СУМНІШЕ!\r\n")}
    if(user.isStateAffected(12)) {text += user.name() + " у БЕЗНАДІЇ...";}
    else if(user.isStateAffected(11)) {text += user.name() + " в ЖУРБІ...";}
    else if(user.isStateAffected(10)) {text += user.name() + " відчуває СУМ.";}
    break;

  case 'ATTACK AGAIN':  // ATTACK AGAIN 2
    text = user.name() + ' атакує знову!\r\n';
    text += hpDamageText;
    break;

  case 'TRIP':  // TRIP
    text = user.name() + ' підставляє підніжку ' + target.name_davalnyi() + '!\r\n';
    if(!target._noStateMessage) {text += 'ШВИДКІСТЬ ' + target.name_rodovyi() + ' знизилася!\r\n';}
    else {text += parseNoStateChange( "ШВИДКІСТЬ", target.name_rodovyi(),"стала нижче!\r\n")}
    text += hpDamageText;
    break;

    case 'TRIP 2':  // TRIP 2
      text = user.name() + ' підставляє підніжку ' + target.name_davalnyi() + '!\r\n';
      if(!target._noStateMessage) {text += 'ШВИДКІСТЬ ' + target.name_rodovyi() + ' знизилася!\r\n';}
      else {text += parseNoStateChange("ШВИДКІСТЬ", target.name_rodovyi(), "стала нижче!\r\n")}
      if(!target._noEffectMessage) {text += target.name() + ' відчуває СУМ.\r\n';}
      else {text += parseNoEffectEmotion(target.name(), "стає СУМНІШЕ!\r\n")}
      text += hpDamageText;
      break;

  case 'STARE': // STARE
    text = user.name() + ' витріщається на ' + target.name_znakhidnyi() + '.\r\n';
    text += target.name() + ' почувається некомфортно.';
    break;

  case 'RELEASE ENERGY':  // RELEASE ENERGY
    text = user.name() + ' та друзі об\'єднуються і\r\n';
    text += 'використовують їхню фінальну атаку!';
    break;

  case 'VERTIGO': // OMORI VERTIGO
    if(target.index() <= unitLowestIndex) {
      text = user.name() + ' виводить ворогів з рівноваги!\r\n';
      text += 'АТАКА всіх\' ворогів знизилася!\r\n';
    }
    text += hpDamageText;
    break;

  case 'CRIPPLE': // OMORI CRIPPLE
    if(target.index() <= unitLowestIndex) {
      text = user.name() + ' калічить ворогів!\r\n';
      text += "ШВИДКІСТЬ усіх ворогів знизилася.\r\n";
    }
    text += hpDamageText;
    break;

  case 'SUFFOCATE': // OMORI SUFFOCATE
    if(target.index() <= unitLowestIndex) {
      text = user.name() + ' душить ворогів!\r\n';
      text += 'Усі вороги задихаються.\r\n';
      text += "ЗАХИСТ усіх ворогів знизився.\r\n";
    }
    text += hpDamageText;
    break;

  //AUBREY//
  case 'PEP TALK':  // PEP TALK
    text = user.name() + ' підбадьорює ' + target.name_znakhidnyi() + '!\r\n';
    if(!target._noEffectMessage) {
      if(target.isStateAffected(8)) {text += target.name() + ' в МАНІЇ!!!';}
      else if(target.isStateAffected(7)) {text += target.name() + ' в ЕКСТАЗІ!!';}
      else if(target.isStateAffected(6)) {text += target.name() + ' відчуває ЩАСТЯ!';}
    }
    else {text += parseNoEffectEmotion(target.name(), "стає ЩАСЛИВІШЕ!")}
    break;

  case 'TEAM SPIRIT':  // TEAM SPIRIT
    text = user.name() + ' підбадьорює ' + target.name_znakhidnyi() + '!\r\n';
    if(!target._noEffectMessage) {
      if(target.isStateAffected(8)) {text += target.name() + ' в МАНІЇ!!!\r\n';}
      else if(target.isStateAffected(7)) {text += target.name() + ' в ЕКСТАЗІ!!\r\n';}
      else if(target.isStateAffected(6)) {text += target.name() + ' відчуває ЩАСТЯ!\r\n';}
    }
    else {text += parseNoEffectEmotion(target.name(), "стає ЩАСЛИВІШЕ!\r\n")}

    if(!user._noEffectMessage) {
      if(user.isStateAffected(8)) {text += user.name() + ' в МАНІЇ!!!';}
      else if(user.isStateAffected(7)) {text += user.name() + ' в ЕКСТАЗІ!!';}
      else if(user.isStateAffected(6)) {text += user.name() + ' відчуває ЩАСТЯ!';}
    }
    else {text += parseNoEffectEmotion(user.name(), "стає ЩАСЛИВІШЕ!\r\n")}
    break;

  case 'HEADBUTT':  // HEADBUTT
    text = user.name() + ' таранить лобом '  + target.name_znakhidnyi() + '!\r\n';
    text += hpDamageText;
    break;

  case 'HOMERUN': // Homerun  
    text = user.name() + ' перевершує ' + target.name_znakhidnyi() + '\r\n';
    text += 'та всіх!\r\n';
    text += hpDamageText;
    break;

  case 'THROW': // Wind-up Throw
    text = user.name() + ' швиряє свою зброю!';
    break;

  case 'POWER HIT': //Power Hit
    text = user.name() + ' вломлює ' + target.name_znakhidnyi() + '!\r\n';
    if(!target._noStateMessage) {text += 'ЗАХИСТ ' + target.name_rodovyi() + ' знизився.\r\n';}
    else {text += parseNoStateChange(target.name_rodovyi(), "ЗАХИСТ", "став нижче!\r\n")}
    text += hpDamageText;
    break;

  case 'LAST RESORT': // Last Resort
    text = user.name() + ' вдаряє ' + target.name_znakhidnyi() + '\r\n';
    text += 'з усієї своєї сили!\r\n';
    text += hpDamageText;
    break;

  case 'COUNTER ATTACK': // Counter Attack
    text = user.name() + ' готує свою биту!';
    break;

  case 'COUNTER HEADBUTT': // Counter Headbutt
    text = user.name() + ' готує свого лоба!';
    break;

  case 'COUNTER ANGRY': //Counter Angry
    text = user.name() + ' готується!';
    break;

  case 'LOOK OMORI 1':  // Look at Omori 2
    text = 'ОМОРІ не помітив ' + user.name_znakhidnyi() + ', тож\r\n';
    text += user.name() + ' атакує знову!\r\n';
    text += hpDamageText;
    break;

  case 'LOOK OMORI 2': // Look at Omori 2
    text = 'ОМОРІ досі не помітив ' + user.name_znakhidnyi() + ', тож\r\n';
    text += user.name() + ' атакує жорсткіше!\r\n';
    text += hpDamageText;
    break;

  case 'LOOK OMORI 3': // Look at Omori 3
    text = 'ОМОРІ нарешті помітив ' + user.name_znakhidnyi() + '!\r\n';
    text += user.name() + ' щасливо розмахує своєю битою!\r\n';
    text += hpDamageText;
    break;

  case 'LOOK KEL 1':  // Look at Kel 1
    text = 'КЕЛ підбурює ОБРІ!\r\n';
    text += target.name() + " відчуває ЗЛІСТЬ!";
    break;

  case 'LOOK KEL 2': // Look at Kel 2
   text = 'КЕЛ підбурює ОБРІ!\r\n';
   text += 'АТАКА КЕЛА та ОБРІ підвищилася!\r\n';
   var AUBREY = $gameActors.actor(2);
   var KEL = $gameActors.actor(3);
   if(AUBREY.isStateAffected(14) && KEL.isStateAffected(14)) {text += 'КЕЛ та ОБРІ відчувають ЗЛІСТЬ!';}
   else if(AUBREY.isStateAffected(14) && KEL.isStateAffected(15)) {
    text += 'КЕЛ відчуває ЛЮТЬ!!\r\n';
    text += 'ОБРІ відчуває ЗЛІСТЬ!';
   }
   else if(AUBREY.isStateAffected(15) && KEL.isStateAffected(14)) {
    text += 'КЕЛ відчуває ЗЛІСТЬ!\r\n';
    text += 'ОБРІ відчуває ЛЮТЬ!!';
   }
   else if(AUBREY.isStateAffected(15) && KEL.isStateAffected(15)) {text += 'КЕЛ та ОБРІ відчувають ЛЮТЬ!!';}
   else {text += 'КЕЛ та ОБРІ відчувають ЗЛІСТЬ!';}
   break;

  case 'LOOK HERO':  // LOOK AT HERO 1
    text = 'ГІРО каже ОБРІ зосередитись!\r\n';
    if(target.isStateAffected(6)) {text += target.name() + " відчуває ЩАСТЯ!\r\n"}
    else if(target.isStateAffected(7)) {text += target.name() + " в ЕКСТАЗІ!!\r\n"}
    text += 'ЗАХИСТ ' + user.name_rodovyi() + ' підвищився!!';
    break;

  case 'LOOK HERO 2': // LOOK AT HERO 2
    text = 'ГІРО підбадьорює ОБРІ!\r\n';
    text += 'ЗАХИСТ ОБРІ підвищився!!\r\n';
    if(target.isStateAffected(6)) {text += target.name() + " відчуває ЩАСТЯ!\r\n"}
    else if(target.isStateAffected(7)) {text += target.name() + " в ЕКСТАЗІ!!\r\n"}
    if(!!$gameTemp._statsState[0]) {
      var absHp = Math.abs($gameTemp._statsState[0] - $gameActors.actor(2).hp);
      if(absHp > 0) {text += `ОБРІ відновлює ${absHp} ЗДОРОВ'Я!\r\n`;}
    }
    if(!!$gameTemp._statsState[1]) {
      var absMp = Math.abs($gameTemp._statsState[1] - $gameActors.actor(2).mp);
      if(absMp > 0) {text += `ОБРІ відновлює ${absMp} СОКУ...`;}
    }
    $gameTemp._statsState = undefined;
    break;

  case 'TWIRL': // ATTACK
    text = user.name() + ' атакує ' + target.name_znakhidnyi() + '!\r\n';
    text += hpDamageText;
    break;

  //KEL//
    case 'ANNOY':  // ANNOY
      text = user.name() + ' дратує ' + target.name_znakhidnyi() + '!\r\n';
      if(!target._noEffectMessage) {
        if(target.isStateAffected(14)) {text += target.name() + ' відчуває ЗЛІСТЬ!';}
        else if(target.isStateAffected(15)) {text += target.name() + ' відчуває ЛЮТЬ!!';}
        else if(target.isStateAffected(16)) {text += target.name() + ' СКАЖЕНІЄ!!!';}
      }
      else {text += parseNoEffectEmotion(target.name(), "стає ЗЛІШЕ!")}
      break;

    case 'REBOUND':  // REBOUND
      text = ' м\'яч ' + user.name_rodovyi() + 'А рикошетить звідусіль!!';
      break;

    case 'FLEX':  // FLEX
      text = user.name() + ' м\'язами грає та міць відчуває!\r\n';
      text += "ШАНС ВЛУЧАННЯ " + user.name_rodovyi() + " підвищився!\r\n"
      break;

    case 'JUICE ME': // JUICE ME
      text = user.name() + ' пасує КОКОСА до ' + target.name_rodovyi() + '!\r\n'
      var absMp = Math.abs(mpDam);
      if(absMp > 0) {
        text += `${target.name()} відновлює ${absMp} СОКУ...\r\n`
      }
      text += hpDamageText;
      break;

    case 'RALLY': // RALLY
      text = user.name() + ' підбадьорює всіх!\r\n';
      if(user.isStateAffected(7)) {text += user.name() + " в ЕКСТАЗІ!!\r\n"}
      else if(user.isStateAffected(6)) {text += user.name() + " відчуває ЩАСТЯ!\r\n"}
      text += "Усі отримують ЕНЕРГІЮ!\r\n"
      for(let actor of $gameParty.members()) {
        if(actor.name() === $gameActors.actor(3).name()) {continue;}
        var result = actor.result();
        if(result.mpDamage >= 0) {continue;}
        var absMp = Math.abs(result.mpDamage);
        text += `${actor.name()} відновлює ${absMp} СОКУ...\r\n`
      }
      break;

    case 'SNOWBALL': // SNOWBALL
      text = user.name() + ' жбурляє СНІЖКУ в\r\n';
      text += target.name_znakhidnyi() + '!\r\n';
      if(!target._noEffectMessage) {text += target.name() + " відчуває СУМ.\r\n"}
      else {text += parseNoEffectEmotion(target.name(), "стає СУМНІШЕ!\r\n")}
      text += hpDamageText;
      break;

    case 'TICKLE': // TICKLE
      text = user.name() + ' лоскоче ' + target.name_znakhidnyi() + '!\r\n'
      text += `${target.name()} втрачає пильність!`
      break;

    case 'RICOCHET': // RICOCHET
     text = user.name() + ' виконує фантастичний трюк з м\'ячем!\r\n';
     text += hpDamageText;
     break;

    case 'CURVEBALL': // CURVEBALL
     text = user.name() + ' кидає крученого м\'яча...\r\n';
     text += target.name() + ' закручується в петлю.\r\n';
     switch($gameTemp._randomState) {
       case 6:
         if(!target._noEffectMessage) {text += target.name() + " відчуває ЩАСТЯ!\r\n"}
         else {text += parseNoEffectEmotion(target.name(), "стає ЩАСЛИВІШЕ!\r\n")}
         break;
      case 14:
        if(!target._noEffectMessage) {text += target.name() + " відчуває ЗЛІСТЬ!\r\n"}
        else {text += parseNoEffectEmotion(target.name(), "стає ЗЛІШЕ!\r\n")}
        break;
      case 10:
        if(!target._noEffectMessage) {text += target.name() + " відчуває СУМ.\r\n"}
        else {text += parseNoEffectEmotion(target.name(), "стає СУМНІШЕ!\r\n")}
        break;

     }
     text += hpDamageText;
     break;

    case 'MEGAPHONE': // MEGAPHONE
      if(target.index() <= unitLowestIndex) {text = user.name() + ' бігає довкола та дратує всіх!\r\n';}
      if(target.isStateAffected(16)) {text += target.name() + ' СКАЖЕНІЄ!!!\r\n'}
      else if(target.isStateAffected(15)) {text += target.name() + ' відчуває ЛЮТЬ!!\r\n'}
      else if(target.isStateAffected(14)) {text += target.name() + ' відчуває ЗЛІСТЬ!\r\n'}
      break;

    case 'DODGE ATTACK': // DODGE ATTACK
      text = user.name() + ' готується до ухиляння!';
      break;

    case 'DODGE ANNOY': // DODGE ANNOY
      text = user.name() + ' починає дражнити ворогів!';
      break;

    case 'DODGE TAUNT': // DODGE TAUNT
      text = user.name() + ' починає насміхатися над ворогами!\r\n';
      text += "ШАНС ВЛУЧАННЯ всіх ворогів знизився на хід!"
      break;

    case 'PASS OMORI':  // KEL PASS OMORI
      text = 'ОМОРІ недогледів та отримав по потилиці!\r\n';
      text += 'ОМОРІ зазнає 1 шкоду!';
      break;

    case 'PASS OMORI 2': //KEL PASS OMORI 2
      text = 'ОМОРІ впіймав м\'яча КЕЛА!\r\n';
      text += 'ОМОРІ жбурнув м\'яча у ' + target.name() + '!\r\n';
      var OMORI = $gameActors.actor(1);
      if(OMORI.isStateAffected(6)) {text += "ОМОРІ відчуває ЩАСТЯ!\r\n"}
      else if(OMORI.isStateAffected(7)) {text += "ОМОРІ в ЕКСТАЗІ!!\r\n"}
      text += hpDamageText;
      break;

    case 'PASS AUBREY':  // KEL PASS AUBREY
      text = 'ОБРІ сильно відбиває м\'яча!\r\n';
      text += hpDamageText;
      break;

    case 'PASS HERO':  // KEL PASS HERO
      if(target.index() <= unitLowestIndex) {text = user.name() + ' відбиває ворогам!\r\n';}
      text += hpDamageText;
      break;

    case 'PASS HERO 2':  // KEL PASS HERO
      if(target.index() <= unitLowestIndex) {
        text = user.name() + ' стильно відбив ворогам!\r\n';
        text += "АТАКА всіх ворогів знизилася!\r\n";
      }
      text += hpDamageText;
      break;

    //HERO//
    case 'MASSAGE':  // MASSAGE
      text = user.name() + ' масажує ' + target.name_znakhidnyi() + '!\r\n';
      if(!!target.isAnyEmotionAffected(true)) {
        text += target.name() + ' заспокоюється...';
      }
      else {text += "Це не дало ніякого ефекту..."}
      break;

    case 'COOK':  // COOK
      text = user.name() + ' пече печиво для ' + target.name_rodovyi() + '!';
      break;

    case 'FAST FOOD': //FAST FOOD
      text = user.name() + ' готує їжу на швидку руку для ' + target.name_rodovyi() + '.';
      break;

    case 'JUICE': // JUICE
      text = user.name() + ' робить освіжаючий напій для ' + target.name_rodovyi() + '.';
      break;

    case 'SMILE':  // SMILE
      text = user.name() + ' усміхається ' + target.name_davalnyi() + '!\r\n';
      if(!target._noStateMessage) {text += 'АТАКА ' + target.name_rodovyi() + ' знизилася.';}
      else {text += parseNoStateChange( "АТАКА", target.name_rodovyi(),"стала нижче!\r\n")}
      break;

    case 'DAZZLE':
      text = user.name() + ' усміхається ' + target.name_davalnyi() + '!\r\n';
      if(!target._noStateMessage) {text += 'АТАКА ' + target.name_rodovyi() + ' знизилася.\r\n';}
      else {text += parseNoStateChange("АТАКА", target.name_rodovyi(), "стала нижче!\r\n")}
      if(!target._noEffectMessage) {
        text += target.name() + ' відчуває ЩАСТЯ';
      }
      else {text += parseNoEffectEmotion(target.name(), "стає ЩАСЛИВІШЕ!")}
      break;
    case 'TENDERIZE': // TENDERIZE
      text = user.name() + ' інтенсивно масажує\r\n';
      text += target.name() + '!\r\n';
      if(!target._noStateMessage) {text += 'ЗАХИСТ ' + target.name_rodovyi() + ' знизився!\r\n';}
      else {text += parseNoStateChange("ЗАХИСТ", target.name_rodovyi(), "став нижче!\r\n")}
      text += hpDamageText;
      break;

    case 'SNACK TIME':  // SNACK TIME
      text = user.name() + ' пече печиво для всіх!';
      break;

    case 'TEA TIME': // TEA TIME
      text = user.name() + ' виносить трохи чаю для перепочинку.\r\n';
      text += target.name() + ' почувається бадьорим!\r\n';
      if(result.hpDamage < 0) {
        var absHp = Math.abs(result.hpDamage);
        text += `${target.name()} відновлює ${absHp} ЗДОРОВ'Я!\r\n`
      }
      if(result.mpDamage < 0) {
        var absMp = Math.abs(result.mpDamage);
        text += `${target.name()} відновлює ${absMp} СОКУ...\r\n`
      }
      break;

    case 'SPICY FOOD': // SPICY FOOD
      text = user.name() + ' готує трохи гострої їжі!\r\n';
      text += hpDamageText;
      break;

    case 'SINGLE TAUNT': // SINGLE TAUNT
      text = user.name() + ' привертає увагу ' + target.name_rodovyi() + '!\r\n';
      break;

    case 'TAUNT':  // TAUNT
      text = user.name() + ' привертає увагу ворога.';
      break;

    case 'SUPER TAUNT': // SUPER TAUNT
      text = user.name() + ' привертає увагу ворога.\r\n';
      text += user.name() + ' готується до блокування ворожих атак.';
      break;

    case 'ENCHANT':  // ENCHANT
      text = user.name() + ' привертає увагу ворога\r\n';
      text += 'з усмішкою.\r\n';
      if(!target._noEffectMessage) {text += target.name() + " відчуває ЩАСТЯ!";}
      else {text += parseNoEffectEmotion(target.name(), "стає ЩАСЛИВІШЕ!")}
      break;

    case 'MENDING': //MENDING
      text = user.name() + ' обслуговує ' + target.name_znakhidnyi() + '.\r\n';
      text += user.name() + ' тепер персональний шеф-кухар для' + target.name_rodovyi() + '!';
      break;

    case 'SHARE FOOD': //SHARE FOOD
      if(target.name() !== user.name()) {
        text = user.name() + ' ділиться їжею з ' + target.name_orudnyi() + '!'
      }
      break;

    case 'CALL OMORI':  // CALL OMORI
      text = user.name() + ' сигналізує ОМОРІ!\r\n';
      if(!!$gameTemp._statsState[0]) {
        var absHp = Math.abs($gameTemp._statsState[0] - $gameActors.actor(1).hp);
        if(absHp > 0) {text += `ОМОРІ відновлює ${absHp} ЗДОРОВ'Я!\r\n`;}
      }
      if(!!$gameTemp._statsState[1]) {
        var absMp = Math.abs($gameTemp._statsState[1] - $gameActors.actor(1).mp);
        if(absMp > 0) {text += `ОМОРІ відновлює ${absMp} СОКУ..`;}
      }
      $gameTemp._statsState = undefined;
      break;

    case 'CALL KEL':  // CALL KEL
      text = user.name() + ' піднімає настрій КЕЛУ!\r\n';
      if(!!$gameTemp._statsState[0]) {
        var absHp = Math.abs($gameTemp._statsState[0] - $gameActors.actor(3).hp);
        if(absHp > 0) {text += `КЕЛ відновлює ${absHp} ЗДОРОВ'Я!\r\n`;}
      }
      if(!!$gameTemp._statsState[1]) {
        var absMp = Math.abs($gameTemp._statsState[1] - $gameActors.actor(3).mp);
        if(absMp > 0) {text += `КЕЛ відновлює ${absMp} СОКУ...`;}
      }
      break;

    case 'CALL AUBREY':  // CALL AUBREY
      text = user.name() + ' заохочує ОБРІ!\r\n';
      if(!!$gameTemp._statsState[0]) {
        var absHp = Math.abs($gameTemp._statsState[0] - $gameActors.actor(2).hp);
        if(absHp > 0) {text += `ОБРІ відновлює ${absHp} ЗДОРОВ'Я!\r\n`;}
      }
      if(!!$gameTemp._statsState[1]) {
        var absMp = Math.abs($gameTemp._statsState[1] - $gameActors.actor(2).mp);
        if(absMp > 0) {text += `ОБРІ відновлює ${absMp} СОКУ...`;}
      }
      break;

    //PLAYER//
    case 'CALM DOWN':  // PLAYER CALM DOWN
      if(item.id !== 1445) {text = user.name() + ' заспокоюється.\r\n';} // Process if Calm Down it's not broken;
      if(Math.abs(hpDam) > 0) {text += user.name() + ' відновлює ' + Math.abs(hpDam) + ' ЗДОРОВ\'Я!';}
      break;

    case 'FOCUS':  // PLAYER FOCUS
      text = user.name() + ' зосереджується.';
      break;

    case 'PERSIST':  // PLAYER PERSIST
      text = user.name() + ' упирається.';
      break;

    case 'OVERCOME':  // PLAYER OVERCOME
      text = user.name() + ' долає.';
      break;

  //UNIVERSAL//
    case 'FIRST AID':  // FIRST AID
      text = user.name() + ' схиляється до ' + target.name_rodovyi() + '!\r\n';
      text += target.name() + ' відновлює ' + Math.abs(target._result.hpDamage) + ' ЗДОРОВ\'Я!';
      break;

    case 'PROTECT':  // PROTECT
      text = user.name() + ' стає перед ' + target.name_orudnyi() + '!';
      break;

    case 'GAURD': // GAURD
      text = user.name() + ' готується блокувати атаки.';
      break;

  //FOREST BUNNY//
    case 'BUNNY ATTACK': // FOREST BUNNY ATTACK
      text = user.name() + ' гризе ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'BUNNY NOTHING': // BUNNY DO NOTHING
      text = user.name() + ' стрибає навколо!';
      break;

    case 'BE CUTE':  // BE CUTE
      text = user.name() + ' підморгує ' + target.name_davalnyi() + '!\r\n';
      text += 'АТАКА ' + target.name_rodovyi() + ' знизилася...';
      break;

    case 'SAD EYES': //SAD EYES
      text = user.name() + ' сумно дивиться на ' + target.name_znakhidnyi() + '.\r\n';
      if(!target._noEffectMessage) {text += target.name() + ' відчуває СУМ.';}
      else {text += parseNoEffectEmotion(target.name(), "стає СУМНІШЕ!")}
      break;

  //FOREST BUNNY?//
    case 'BUNNY ATTACK2': // BUNNY? ATTACK
      text = user.name() + ' гризе ' + target.name_znakhidnyi() + '?\r\n';
      text += hpDamageText;
      break;

    case 'BUNNY NOTHING2':  // BUNNY? DO NOTHING
      text = user.name() + ' стрибає навколо?';
      break;

    case 'BUNNY CUTE2':  // BE CUTE?
      text = user.name() + 'підморгує ' + target.name_davalnyi() + '?\r\n';
      text += 'АТАКА' + target.name_rodovyi() + ' знизилася?';
      break;

    case 'SAD EYES2': // SAD EYES?
      text = user.name() + ' сумно дивиться на ' + target.name_znakhidnyi() + '...\r\n';
      if(!target._noEffectMessage) {text += target.name() + ' відчуває СУМ?';}
      else {text += parseNoEffectEmotion(target.name(), "стає СУМНІШЕ!")}
      break;

    //SPROUT MOLE//
    case 'SPROUT ATTACK':  // SPROUT MOLE ATTACK
      text = user.name() + ' натикається на ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'SPROUT NOTHING':  // SPROUT NOTHING
      text = user.name() + ' катається навколо.';
      break;

    case 'RUN AROUND':  // RUN AROUND
      text = user.name() + ' бігає навколо!';
      break;

    case 'HAPPY RUN AROUND': //HAPPY RUN AROUND
      text = user.name() + ' енергійно бігає навколо!';
       break;

    //MOON BUNNY//
    case 'MOON ATTACK':  // MOON BUNNY ATTACK
      text = user.name() + ' влітає в ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'MOON NOTHING':  // MOON BUNNY NOTHING
      text = user.name() + ' віддаляється.';
      break;

    case 'BUNNY BEAM':  // BUNNY BEAM
      text = user.name() + ' стріляє лазером!\r\n';
      text += hpDamageText;
      break;

    //DUST BUNNY//
    case 'DUST NOTHING':  // DUST NOTHING
      text = user.name() + ' намагається триматися\r\n';
      text += 'купи.';
      break;

    case 'DUST SCATTER':  // DUST SCATTER
      text = user.name() + ' вибухає!';
      break;

    //U.F.O//
    case 'UFO ATTACK':  // UFO ATTACK
      text = user.name() + ' розбивається об ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'UFO NOTHING':  // UFO NOTHING
      text = user.name() + ' втрачає інтерес.';
      break;

    case 'STRANGE BEAM':  // STRANGE BEAM
      text = user.name() + ' спалахує дивним світлом!\r\n';
      text += target.name() + " відчуває випадкову ЕМОЦІЮ!"
      break;

    case 'ORANGE BEAM':  // ORANGE BEAM
      text = user.name() + ' стріляє помаранчевим лазером!\r\n';
      text += hpDamageText;
      break;

    //VENUS FLYTRAP//
    case 'FLYTRAP ATTACK':  // FLYTRAP ATTACK
      text = user.name() + ' ударяє ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'FLYTRAP NOTHING':  // FLYTRAP NOTHING
      text = user.name() + ' гризе порожнечу.';
      break;

    case 'FLYTRAP CRUNCH':  // FLYTRAP
      text = user.name() + ' кусає ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    //WORMHOLE//
    case 'WORM ATTACK':  // WORM ATTACK
      text = user.name() + ' шльопає ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'WORM NOTHING':  // WORM NOTHING
      text = user.name() + ' хитається навколо...';
      break;

    case 'OPEN WORMHOLE':  // OPEN WORMHOLE
      text = user.name() + ' відкриває червоточину!';
      break;

    //MIXTAPE//
    case 'MIXTAPE ATTACK':  // MIXTAPE ATTACK
      text = user.name() + ' шльопає ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'MIXTAPE NOTHING':  // MIXTAPE NOTHING
      text = user.name() + ' сама себе розплутує.';
      break;

    case 'TANGLE':  // TANGLE
      text = target.name() + ' потрапляє у пастку ' + user.name_rodovyi() + '!\r\n';
      text += 'ШВИДКІСТЬ ' + target.name_rodovyi() + ' знизилася...';
      break;

    //DIAL-UP//
    case 'DIAL ATTACK':  // DIAL ATTACK
      text = user.name() + ' повільне.\r\n';
      var pronumn = target.name() === $gameActors.actor(2).name() ? "її" : "його";
      text += `${target.name()} б'є себе в фрустрації!\r\n`;
      text += hpDamageText;
      break;

    case 'DIAL NOTHING':  // DIAL NOTHING
      text = user.name() + ' завантажується...';
      break;

    case 'DIAL SLOW':  // DIAL SLOW
      text = user.name() + ' упо-о-о-о-овільнюється.\r\n';
      text += 'У всіх знизилася ШВИДКІСТЬ...';
      break;

    //DOOMBOX//
    case 'DOOM ATTACK':  // DOOM ATTACK
      text = user.name() + ' врізається в' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'DOOM NOTHING':  // DOOM NOTHING
      text = user.name() + ' налаштовує радіо.';
      break;

    case 'BLAST MUSIC':  // BLAST MUSIC
      text = user.name() + ' викидає якісь незрозумілі біти!';
      break;

    //SHARKPLANE//
    case 'SHARK ATTACK':  // SHARK PLANE
      text = user.name() + ' тараниться в ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'SHARK NOTHING':  // SHARK NOTHING
      text = user.name() + ' збирає свої зуби.';
      break;

    case 'OVERCLOCK ENGINE':  // OVERCLOCK ENGINE
      text = user.name() + ' розкручує свій двигун!\r\n';
      if(!target._noStateMessage) {
        text += 'ШВИДКІСТЬ ' + user.name_rodovyi() + ' підвищилася!';
      }
      else {text += parseNoStateChange("ШВИДКІСТЬ", user.name_rodovyi(), "стала вище!")}
      break;

    case 'SHARK CRUNCH':  // SHARK
        text = user.name() + ' кусає ' + target.name_znakhidnyi() + '!\r\n';
        text += hpDamageText;
        break;

    //SNOW BUNNY//
    case 'SNOW BUNNY ATTACK':  // SNOW ATTACK
      text = user.name() + ' кидається снігом у ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'SNOW NOTHING':  // SNOW NOTHING
      text = user.name() + ' відпочиває.';
      break;

    case 'SMALL SNOWSTORM':  // SMALL SNOWSTORM
      text = user.name() + ' кидається у всіх снігом,\r\n';
      text += 'спричиняючи найменшу хуртовину на світі!';
      break;

    //SNOW ANGEL//
    case 'SNOW ANGEL ATTACK': //SNOW ANGEL ATTACK
      text = user.name() + ' торкається ' + target.name_rodovyi() + '\r\n';
      text += 'своїми холодними руками.\r\n';
      text += hpDamageText;
      break;

    case 'UPLIFTING HYMN': //UPLIFTING HYMN
      if(target.index() <= unitLowestIndex) {
        text = user.name() + ' співає гарну пісню...\r\n';
        text += 'Усі відчувають ЩАСТЯ!';
      }
      target._noEffectMessage = undefined;
      break;

    case 'PIERCE HEART': //PIERCE HEART
      text = user.name() + ' проколює серце ' + target.name_davalnyi() + '.\r\n';
      text += hpDamageText;
      break;

    //SNOW PILE//
    case 'SNOW PILE ATTACK': //SNOW PILE ATTACK
      text = user.name() + ' жбурляє сніг у ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'SNOW PILE NOTHING': //SNOW PILE NOTHING
      text = user.name() + ' відчуває морозець.';
      break;

    case 'SNOW PILE ENGULF': //SNOW PILE ENGULF
      text = user.name() + ' занурює ' + target.name_znakhidnyi() + ' у сніг!\r\n';
      text += 'ШВИДКІСТЬ ' + user.name_rodovyi() + ' знизилася.\r\n';
      text += 'ЗАХИСТ ' + user.name_rodovyi() + ' знизився.';
      break;

    case 'SNOW PILE MORE SNOW': //SNOW PILE MORE SNOW
      text = user.name() + ' накидає на себе сніг!\r\n';
      text += 'АТАКА ' + user.name_rodovyi() + ' підвищилася!\r\n';
      text += 'ЗАХИСТ ' + user.name_rodovyi() + ' підвищився!';
      break;

    //CUPCAKE BUNNY//
    case 'CCB ATTACK': //CUP CAKE BUNNY ATTACK
      text = user.name() + ' вдаряється у ' + target.name_znakhidnyi() + '.\r\n';
      text += hpDamageText;
      break;

    case 'CCB NOTHING': //CUP CAKE BUNNY NOTHING
      text = user.name() + ' підстрибує на місці.';
      break;

    case 'CCB SPRINKLES': //CUP CAKE BUNNY SPRINKLES
      text = user.name() + ' посипає ' + target.name_znakhidnyi() + '\r\n';
      text += 'посипкою.\r\n';
      if(!target._noEffectMessage) {text += target.name() + ' відчуває ЩАСТЯ!\r\n';}
      else {text += parseNoEffectEmotion(target.name(), "стає ЩАСЛИВІШЕ!\r\n")}
      text += "ПОКАЗНИКИ " + target.name_rodovyi() + " ПІДВИЩИЛИСЬ!"
      break;

    //MILKSHAKE BUNNY//
    case 'MSB ATTACK': //MILKSHAKE BUNNY ATTACK
      text = user.name() + ' виливає молочний коктейль на ' + target.name_znakhidnyi() + '.\r\n';
      text += hpDamageText;
      break;

    case 'MSB NOTHING': //MILKSHAKE BUNNY NOTHING
      text = user.name() + ' обертається по колу.';
      break;

    case 'MSB SHAKE': //MILKSHAKE BUNNY SHAKE
      text = user.name() + ' починає люто тремтіти!\r\n';
      text += 'Молочний коктейль літає всюди!';
      break;

    //PANCAKE BUNNY//
    case 'PAN ATTACK': //PANCAKE BUNNY ATTACK
      text = user.name() + ' гризе ' + target.name_znakhidnyi() + '.\r\n';
      text += hpDamageText;
      break;

    case 'PAN NOTHING': //PANCAKE BUNNY NOTHING
      text = user.name() + ' робить сальто!\r\n';
      text += 'Дуже талановито!';
      break;

    //STRAWBERRY SHORT SNAKE//
    case 'SSS ATTACK': //STRAWBERRY SHORT SNAKE ATTACK
      text = user.name() + ' занурює свої ікла в ' + target.name_znakhidnyi() + '.\r\n';
      text += hpDamageText;
      break;

    case 'SSS NOTHING': //STRAWBERRY SHORT SNAKE NOTHING
      text = user.name() + ' шипить.';
      break;

    case 'SSS SLITHER': //STRAWBERRY SHORT SNAKE SLITHER
      text = user.name() + ' радісно повзає навколо!\r\n';
      if(!user._noEffectMessage) {text += user.name() + ' відчуває ЩАСТЯ!';}
      else {text += parseNoEffectEmotion(user.name(), "стає ЩАСЛИВІШЕ!")}
      break;

    //PORCUPIE//
    case 'PORCUPIE ATTACK': //PORCUPIE ATTACK
      text = user.name() + ' тикає у ' + target.name_znakhidnyi() + '.\r\n';
      text += hpDamageText;
      break;

    case 'PORCUPIE NOTHING': //PORCUPIE NOTHING
      text = user.name() + ' обнюхує все навколо.';
      break;

    case 'PORCUPIE PIERCE': //PORCUPIE PIERCE
      text = user.name() + ' проколює ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    //BUN BUNNY//
    case 'BUN ATTACK': //BUN ATTACK
      text = user.name() + ' вдаряє булочками ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'BUN NOTHING': //BUN NOTHING
      text = user.name() + ' байдикує.';
      break;

    case 'BUN HIDE': //BUN HIDE
      text = user.name() + ' ховається у своїй булочці.';
      break;

    //TOASTY//
    case 'TOASTY ATTACK': //TOASTY ATTACK
      text = user.name() + ' заряджає в ' + target.name_znakhidnyi() + '.\r\n';
      text += hpDamageText;
      break;

    case 'TOASTY NOTHING': //TOASTY NOTHING
      text = user.name() + ' колупається в носі.';
      break;

    case 'TOASTY RILE': //TOASTY RILE
      if(target.index() <= unitLowestIndex) {
        text = user.name() + ' виголошує суперечливу промову!\r\n';
        text += 'Усі відчувають ЗЛІСТЬ!';
      }
      target._noEffectMessage = undefined;
      break;

    //SOURDOUGH//
    case 'SOUR ATTACK': //SOURDOUGH ATTACK
      text = user.name() + ' наступає на пальці ніг' + target.name_rodovyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'SOUR NOTHING': //SOURDOUGH NOTHING
      text = user.name() + ' відкидає ногою грязюку.';
      break;

    case 'SOUR BAD WORD': //SOURDOUGH BAD WORD
      text = 'О ні! ' + user.name() + ' сказала погане слово!\r\n';
      text += hpDamageText;
      break;

    //SESAME//
    case 'SESAME ATTACK': //SESAME ATTACK
      text = user.name() + ' кидається насінням у ' + target.name_znakhidnyi() + '.\r\n';
      text += hpDamageText;
      break;

    case 'SESAME NOTHING': //SESAME Nothing
      text = user.name() + ' чухає свою макітру.';
      break;

    case 'SESAME ROLL': //SESAME BREAD ROLL
      if(target.index() <= unitLowestIndex) {
        text = user.name() + ' перевертає всіх!\r\n';
      }
      text += hpDamageText;
      break;

    //CREEPY PASTA//
    case 'CREEPY ATTACK': //CREEPY ATTACK
      text = user.name() + ' змушує ' + target.name_znakhidnyi() + ' почуватися\r\n';
      text += 'некомфортно.\r\n';
      text += hpDamageText;
      break;

    case 'CREEPY NOTHING': //CREEPY NOTHING
      text = user.name() + ' загрозливо... нічого не робить!';
      break;

    case 'CREEPY SCARE': //CREEPY SCARE
      text = user.name() + ' демонструє всім їхні найгірші\r\n';
      text += 'кошмари!';
      break;

    //COPY PASTA//
    case 'COPY ATTACK': //COPY ATTACK
      text = user.name() + ' буцає ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'DUPLICATE': //DUPLICATE
      text = user.name() + ' копіює самого себе!';
      break;

    //HUSH PUPPY//
    case 'HUSH ATTACK': //HUSH ATTACK
      text = user.name() + ' тараниться в ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'HUSH NOTHING': //HUSH NOTHING
      text = user.name() + ' намагається гавкати...\r\n';
      text += 'Але нічого не виходить...';
      break;

    case 'MUFFLED SCREAMS': //MUFFLED SCREAMS
      text = user.name() + ' починає верещати!\r\n';
      if(!target._noEffectMessage && target.name() !== "ОМОРІ") {
        text += target.name() + ' у ЖАХУ.';
      }
      else {text += parseNoEffectEmotion(target.name(), "ЖАХ")}
      break;

    //GINGER DEAD MAN//
    case 'GINGER DEAD ATTACK': //GINGER DEAD MAN ATTACK
      text = user.name() + ' штрикає ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'GINGER DEAD NOTHING': //GINGER DEAD MAN DO NOTHING
      text = 'У ' + user.name_rodovyi() + ' відлетіла голова...\r\n';
      text += user.name() + ' надягає голову назад.';
      break;

    case 'GINGER DEAD THROW HEAD': //GINGER DEAD MAN THROW HEAD
      text = user.name() + ' жбурляє свою голову в\r\n';
      text +=  target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    //LIVING BREAD//
    case 'LIVING BREAD ATTACK': //LIVING BREAD ATTACK
      text = user.name() + ' шмагонув ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'LIVING BREAD NOTHING': //LIVING BREAD ATTACK
      text = user.name() + ' повільно просувається до\r\n';
      text += target.name() + '!';
      break;

    case 'LIVING BREAD BITE': //LIVING BREAD BITE
      text = user.name() + ' кусає ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'LIVING BREAD BAD SMELL': //LIVING BREAD BAD SMELL
      text = user.name() + ' погано пахне!\r\n';
      text += 'ЗАХИСТ' + target.name_rodovyi() + ' знизився!';
      break;

    //Bug Bunny//
    case 'BUG BUN ATTACK': //Bug Bun Attack
     text = user.name() + ' шмагонув ' + target.name_znakhidnyi() + '!\r\n';
     text += hpDamageText;
     break;

    case 'BUG BUN NOTHING': //Bug Bun Nothing
      text = user.name() + ' намагається втриматись';
      text += 'на голові.';
      break;

    case 'SUDDEN JUMP': //SUDDEN JUMP
      text = user.name() + ' несподівано кидається';
      text += 'на ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'SCUTTLE': //Bug Bun Scuttle
      text = user.name() + ' щасливо швендяє навколо.\r\n';
      text += 'Це було справді мило!\r\n';
      if(!user._noEffectMessage) {text += user.name() + ' відчуває ЩАСТЯ!';}
      else {text += parseNoEffectEmotion(user.name(), "стає ЩАСЛИВІШЕ!")}
      break;

    //RARE BEAR//
    case 'BEAR ATTACK': //BEAR ATTACK
      text = user.name() + ' розсікає ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'BEAR HUG': //BEAR HUG
      text = user.name() + ' обіймає ' + target.name_znakhidnyi() + '!\r\n';
      text += 'ШВИДКІСТЬ ' + target.name_rodovyi() + ' знизилася!\r\n';
      text += hpDamageText;
      break;

    case 'ROAR': //ROAR
      text = user.name() + ' видає гучний рев!\r\n';
      if(!user._noEffectMessage) {text += user.name() + ' відчуває ЗЛІСТЬ!';}
      else {text += parseNoEffectEmotion(user.name(), "стає ЗЛІШЕ!")}
      break;

    //POTTED PALM//
    case 'PALM ATTACK': //PALM ATTACK
      text = user.name() + ' врізається в ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'PALM NOTHING': //PALM NOTHING
      text = user.name() + ' відпочиває у своєму горщику.';
      break;

    case 'PALM TRIP': //PALM TRIP
      text = target.name() + ' спотикається о коріння ' + user.name_rodovyi() + '.\r\n';
      text += hpDamageText + '.\r\n';
      text += 'ШВИДКІСТЬ ' + target.name_rodovyi() + ' знизилася.';
      break;

    case 'PALM EXPLOSION': //PALM EXPLOSION
      text = user.name() + ' вибухає!';
      break;

    //SPIDER CAT//
    case  'SPIDER ATTACK': //SPIDER ATTACK
      text = user.name() + ' кусає ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'SPIDER NOTHING': //SPIDER NOTHING
      text = user.name() + ' відкашлює клубок павутиння.';
      break;

    case 'SPIN WEB': //SPIN WEB
       text = user.name() + ' стріляє павутиною у ' + target.name_znakhidnyi() + '!\r\n';
       text += 'ШВИДКІСТЬ ' + target.name_rodovyi() + ' знизилася.';
       break;

    //SPROUT MOLE?//
    case 'SPROUT ATTACK 2':  // SPROUT MOLE? ATTACK
      text = user.name() + ' шльопає ' + target.name_znakhidnyi() + '?\r\n';
      text += hpDamageText;
      break;

    case 'SPROUT NOTHING 2':  // SPROUT MOLE? NOTHING
      text = user.name() + ' катається навколо?';
      break;

    case 'SPROUT RUN AROUND 2':  // SPROUT MOLE? RUN AROUND
      text = user.name() + ' бігає навколо?';
      break;

    //HAROLD//
    case 'HAROLD ATTACK': //HAROLD ATTACK
      text = user.name() + ' замахнувся мечем на ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'HAROLD NOTHING': // HAROLD NOTHING
      text = user.name() + ' поправляє свій шолом.';
      break;

    case 'HAROLD PROTECT': // HAROLD PROTECT
      text = user.name() + ' захищається.';
      break;

    case 'HAROLD WINK': //HAROLD WINK
      text = user.name() + ' підморгує ' + target.name_davalnyi() + '.\r\n';
      if(!target._noEffectMessage) {text += target.name() + ' відчуває ЩАСТЯ!';}
      else {text += parseNoEffectEmotion(target.name(), "стає ЩАСЛИВІШЕ!")}
      break;

    //MARSHA//
    case 'MARSHA ATTACK': //MARSHA ATTACK
      text = user.name() + ' замахується сокирою на ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'MARSHA NOTHING': //MARSHA NOTHING
      text = user.name() + ' падає на землю.';
      break;

    case 'MARSHA SPIN': //MARSHA NOTHING
      text = user.name() + ' починає обертатися зі швидкістю світла!\r\n';
      text += hpDamageText;
      break;

    case 'MARSHA CHOP': //MARSHA CHOP
      text = user.name() + ' вдаряє сокирою по' + target.name_davalnyi() + '!\r\n';
      text += hpDamageText;
      break;

    //THERESE//
    case 'THERESE ATTACK': //THERESE ATTACK
      text = user.name() + ' випускає стрілу в ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'THERESE NOTHING': //THERESE NOTHING
      text = user.name() + ' вроняє стрілу.';
      break;

    case 'THERESE SNIPE': //THERESE SNIPE
      text = user.name() + ' влучно стріляє у вразливе місце ' + target.name_rodovyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'THERESE INSULT': //THERESE INSULT
      text = user.name() + ' обзиває ' + target.name_znakhidnyi() + ' малим гімном!\r\n';
      if(!target._noEffectMessage) {text += target.name() + ' відчуває ЗЛІСТЬ!\r\n';}
      else {text += parseNoEffectEmotion(target.name(), "стає ЗЛІШЕ!\r\n")}
      text += hpDamageText;
      break;

    case 'DOUBLE SHOT': //THERESE DOUBLE SHOT
      text = user.name() + ' пускає дві стріли одночасно!';
      break;

    //LUSCIOUS//
    case 'LUSCIOUS ATTACK': //LUSCIOUS ATTACK
      text = user.name() + ' намагається промовити заклинання...\r\n';
      text += user.name() + ' зробив щось кальмагічне!\r\n';
      text += hpDamageText;
      break;

    case 'LUSCIOUS NOTHING': //LUSCIOUS NOTHING
      text = user.name() + ' намагається промовити заклинання...\r\n';
      text += 'Але нічого не відбувається...';
      break;

    case 'FIRE MAGIC': //FIRE MAGIC
      text = user.name() + ' намагається промовити заклинання...\r\n';
      text += user.name() + ' накриває команду вогнем!\r\n';
      text += hpDamageText;
      break;

    case 'MISFIRE MAGIC': //MISFIRE MAGIC
      text = user.name() + ' намагається промовити заклинання...\r\n';
      text += user.name() + ' заповнює простір вогнем!!!\r\n';
      text += hpDamageText;
      break;

    //HORSE HEAD//
    case 'HORSE HEAD ATTACK': //HORSE HEAD ATTACK
      text = user.name() + ' кусає руку ' + target.name_rodovyi() + '.\r\n';
      text += hpDamageText;
      break;

    case 'HORSE HEAD NOTHING': //HORSE HEAD NOTHING
      text = user.name() + ' відригує.';
      break;

    case 'HORSE HEAD LICK': //HORSE HEAD LICK
     text = user.name() + ' лиже волосся ' + target.name_rodovyi() + '.\r\n';
     text += hpDamageText + '\r\n';
     if(!target._noEffectMessage) {text += target.name() + ' відчуває ЗЛІСТЬ';}
     else {text += parseNoEffectEmotion(target.name(), "стає ЗЛІШЕ!")}
     break;

    case 'HORSE HEAD WHINNY': //HORSE HEAD WHINNY
      text = user.name() + ' скиглить від щастя!';
      break;

    //HORSE BUTT//
    case 'HORSE BUTT ATTACK': //HORSE BUTT ATTACK
      text = user.name() + ' затоптує ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'HORSE BUTT NOTHING': //HORSE BUTT NOTHING
      text = user.name() + ' пердить.';
      break;

    case 'HORSE BUTT KICK': //HORSE BUTT KICK
      text = user.name() + ' б\'є копитами ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'HORSE BUTT PRANCE': //HORSE BUTT PRANCE
      text = user.name() + ' гарцює навколо.';
      break;

    //FISH BUNNY//
    case 'FISH BUNNY ATTACK': //FISH BUNNY ATTACK
      text = user.name() + ' занирює у ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'FISH BUNNY NOTHING': //FISH BUNNY NOTHING
      text = user.name() + ' плаває по колу.';
      break;

    case 'SCHOOLING': //SCHOOLING
      text = user.name() + ' гукає друзів!';
      break;

    //MAFIA ALLIGATOR//
    case 'MAFIA ATTACK': //MAFIA ATTACK
      text = user.name() + ' кусає в стилі карате ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'MAFIA NOTHING': //MAFIA NOTHING
      text = user.name() + ' хрустить пальцями.';
      break;

    case 'MAFIA ROUGH UP': //MAFIA ROUGH UP
      text = user.name() + ' задирає ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'MAFIA BACK UP': //MAFIA ALLIGATOR BACKUP
      text = user.name() + ' викликає підкріплення!';
      break;

    //MUSSEL//
    case 'MUSSEL ATTACK': //MUSSEL ATTACK
      text = user.name() + ' вдаряє ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'MUSSEL FLEX': //MUSSEL FLEX
     text = user.name() + ' м\'язами грає та міць відчуває!\r\n';
     text += "ШАНС ВЛУЧАННЯ " + user.name_rodovyi() + " підвищився!\r\n"
     break;

    case 'MUSSEL HIDE': //MUSSEL HIDE
     text = user.name() + ' ховається у своїй ракушці.';
     break;

    //REVERSE MERMAID//
    case 'REVERSE ATTACK': //REVERSE ATTACK
     text = target.name() + ' наштовхується на ' + user.name_znakhidnyi() + '!\r\n';
     text += hpDamageText;
     break;

    case 'REVERSE NOTHING': //REVERSE NOTHING
     text = user.name() + ' робить сальто назад!\r\n';
     text += 'ВАУ!';
     break;

    case 'REVERSE RUN AROUND': //REVERSE RUN AROUND
      text = 'Всі втікають від ' + user.name_rodovyi() + ',\r\n';
      text += 'але замість того наштовхуються на неї...\r\n';
      text += hpDamageText;
      break;

    //SHARK FIN//
    case 'SHARK FIN ATTACK': //SHARK FIN ATTACK
      text = user.name() + ' рушила на ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'SHARK FIN NOTHING': //SHARK FIN NOTHING
      text = user.name() + ' плаває по колу.';
      break;

    case 'SHARK FIN BITE': //SHARK FIN BITE
      text = user.name() + ' кусає ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'SHARK WORK UP': //SHARK FIN WORK UP
      text = user.name() + ' працює над собою!\r\n';
      text += 'ШВИДКІСТЬ ' + user.name_rodovyi() + ' підвищилася!\r\n';
      if(!user._noEffectMessage) {
        text += user.name() + ' відчуває ЗЛІСТЬ!';
      }
      else {text += parseNoEffectEmotion(user.name(), "стає ЗЛІШЕ!")}
      break;

    //ANGLER FISH//
    case 'ANGLER ATTACK': //ANGLER FISH ATTACK
      text = user.name() + ' кусає ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'ANGLER NOTHING': //ANGLER FISH NOTHING
      text = 'У' + user.name_rodovyi() + 'бурчить живіт.';
      break;

    case 'ANGLER LIGHT OFF': //ANGLER FISH LIGHT OFF
      text = user.name() + ' вимикає своє світло.\r\n';
      text += user.name() + ' зникає у темряві.';
      break;

    case 'ANGLER BRIGHT LIGHT': //ANGLER FISH BRIGHT LIGHT
      text = 'Усі бачать, як їхнє життя промайнуло\r\n';
      text += 'перед очима!';
      break;

    case 'ANGLER CRUNCH': //ANGLER FISH CRUNCH
      text = user.name() + ' впивається зубами у ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    //SLIME BUNNY//
    case 'SLIME BUN ATTACK': //SLIME BUNNY ATTACK
      text = user.name() + ' притуляється до ' + target.name_rodovyi() +'.\r\n';
      text += hpDamageText;
      break;

    case 'SLIME BUN NOTHING': //SLIME BUN NOTHING
      text = user.name() + ' усміхається всім.\r\n';
      break;

    case 'SLIME BUN STICKY': //SLIME BUN STICKY
      text = user.name() + ' почувається самотньо та плаче.\r\n';
      if(!target._noStateMessage) {text += 'ШВИДКІСТЬ ' + target.name_rodovyi() + ' знизилася!\r\n';}
      else {text += parseNoStateChange("ШВИДКІСТЬ", target.name_rodovyi(), "стала нижче!\r\n")}
      text += target.name() + " відчуває СУМ.";
      break;

    //WATERMELON MIMIC//
    case 'WATERMELON RUBBER BAND': //WATERMELON MIMIC RUBBER BAND
      text = user.name() + ' жбурляє ГУМОВУ РЕЗИНКУ!\r\n';
      text += hpDamageText;
      break;

    case 'WATERMELON JACKS': //WATERMELON MIMIC JACKS
      text = user.name() + ' розкидає ДЖЕКС усюди!\r\n';
      text += hpDamageText;
      break;

    case 'WATERMELON DYNAMITE': //WATERMELON MIMIC DYNAMITE
      text = user.name() + ' підпалює ДИНАМІТ!\r\n';
      text += 'О НІ!\r\n';
      text += hpDamageText;
      break;

    case 'WATERMELON WATERMELON SLICE': //WATERMELON MIMIC WATERMELON SLICE
      text = user.name() + ' кидає СІК З КАВУНА!\r\n';
      text += hpDamageText;
      break;

    case 'WATERMELON GRAPES': //WATERMELON MIMIC GRAPES
      text = user.name() + ' кидає СОДОВУ З ВИНОГРАДОМ!\r\n';
      text += hpDamageText;
      break;

    case 'WATEMELON FRENCH FRIES': //WATERMELON MIMIC FRENCH FRIES
      text = user.name() + ' кидає КАРТОПЛЮ ФРІ!\r\n';
      text += hpDamageText;
      break;

    case 'WATERMELON CONFETTI': //WATERMELON MIMIC CONFETTI
      if(target.index() <= unitLowestIndex) {
        text = user.name() + ' кидає КОНФЕТІ!\r\n';
        text += "Усі відчувають ЩАСТЯ!"
      }
      target._noEffectMessage = undefined;
      break;

    case 'WATERMELON RAIN CLOUD': //WATERMELON MIMIC RAIN CLOUD
      if(target.index() <= unitLowestIndex) {
        text = user.name() + ' викликає ДОЩОВУ ХМАРУ!\r\n';
        text += "Усі відчувають СУМ."
      }
      target._noEffectMessage = undefined;
      break;

    case 'WATERMELON AIR HORN': //WATERMELON MIMIC AIR HORN
      if(target.index() <= unitLowestIndex) {
        text = user.name() + ' гуде ГІГАНТСЬКИМ ГУДКОМ!\r\n';
        text += "Усі відчувають ЗЛІСТЬ!"
      }
      target._noEffectMessage = undefined;
      break;

    //SQUIZZARD//
    case 'SQUIZZARD ATTACK': //SQUIZZARD ATTACK
      text = user.name() + ' накликає магію на ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'SQUIZZARD NOTHING': //SQUIZZARD NOTHING
      text = user.name() + ' бубонить нісенітниці.';
      break;

    case 'SQUID WARD': //SQUID WARD
      text = user.name() + ' створює кальсторожа.\r\n';
      text += 'ЗАХИСТ ' + target.name_rodovyi() + ' підвищився.';
      break;

    case  'SQUID MAGIC': //SQUID MAGIC
      text = user.name() +  ' чаклує кальмагію!\r\n';
      text += 'Всі почуваються дивно...';
      break;

    //WORM-BOT//
    case 'BOT ATTACK': //MECHA WORM ATTACK
      text = user.name() + ' вдаряється у ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'BOT NOTHING': //MECHA WORM NOTHING
      text = user.name() + ' голосно хрускає!';
      break;

    case 'BOT LASER': //MECHA WORM CRUNCH
      text = user.name() + ' стріляє лазером у ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'BOT FEED': //MECHA WORM FEED
      text = user.name() + ' їсть ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;


    //SNOT BUBBLE//
    case 'SNOT INFLATE': //SNOT INFLATE
      text = user.name() + ' надувається!\r\n';
      text += 'АТАКА ' + target.name_rodovyi() + ' підвищилася!';
      break;

    case 'SNOT POP': //SNOT POP
      text = user.name() + ' вибухає!\r\n';
      text += 'Шмарклі літають всюди!!\r\n';
      text += hpDamageText;
      break;

    //LAB RAT//
    case  'LAB ATTACK': //LAB RAT ATTACK
      text = user.name() + ' стріляє крихітним мишачим лазером!\r\n';
      text += hpDamageText;
      break;

    case  'LAB NOTHING': //LAB RAT NOTHING
      text = user.name() + ' випускає трохи пари.';
      break;

    case  'LAB HAPPY GAS': //LAB RAT HAPPY GAS
      text = user.name() + ' випускає ЩАСЛИВИЙ\r\n';
      text += 'газ!! Усі відчувають ЩАСТЯ!';
      target._noEffectMessage = undefined;
      break;

    case  'LAB SCURRY': //LAB RAT SCURRY
      text = user.name() + ' носиться навколо!\r\n';
      break;

    //MECHA MOLE//
    case 'MECHA MOLE ATTACK': //MECHA MOLE ATTACK
      text = user.name() + ' стріляє лазером у ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'MECHA MOLE NOTHING': //MECHA MOLE NOTHING
      text = 'Око ' + user.name_rodovyi() + ' трохи світиться.';
      break;

    case 'MECHA MOLE EXPLODE': //MECHA MOLE EXPLODE
      text = user.name() + ' випускає скупу сльозу.\r\n';
      text += user.name() + ' славетно вибухає!';
      break;

    case 'MECHA MOLE STRANGE LASER': //MECHA MOLE STRANGE LASER
      text = 'Очі ' + user.name_rodovyi() + ' випромінюють\r\n';
      text += 'химерне світло. ' + target.name() + ' має дивне відчуття.';
      break;

    case 'MECHA MOLE JET PACK': //MECHA MOLE JET PACK
      text = 'Реактивний ранець з\'явився на ' + user.name_davalnyi() + '!\r\n';
      text += user.name() + ' пролетів крізь усіх!';
      break;

    //CHIMERA CHICKEN//
    case 'CHICKEN RUN AWAY': //CHIMERA CHICKEN RUN AWAY
      text = user.name() + ' тікає.';
      break;

    case 'CHICKEN NOTHING': //CHICKEN DO NOTHING
      text = user.name() + ' кудахтає. ';
      break;

    //SALLI//
    case 'SALLI ATTACK': //SALLI ATTACK
      text = user.name() + ' наштовхується на ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'SALLI NOTHING': //SALLI NOTHING
      text = user.name() + ' робить маленьке сальто!';
      break;

    case 'SALLI SPEED UP': //SALLI SPEED UP
      text = user.name() + ' починає гасати по приміщенню!\r\n';
      if(!target._noStateMessage) {
        text += 'ШВИДКІСТЬ ' + user.name_rodovyi() + ' підвищилася!';
      }
      else {text += parseNoStateChange("ШВИДКІСТЬ", user.name_rodovyi(), "стала вище!")}
      break;

    case 'SALLI DODGE ANNOY': //SALLI STARE
      text = user.name() + ' починає інтенсивно зосереджуватись!';
      break;

    //CINDI//
    case 'CINDI ATTACK': //CINDI ATTACK
      text = user.name() + ' вдаряє ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'CINDI NOTHING': //CINDI NOTHING
      text = user.name() + ' крутиться по колу.';
      break;

    case 'CINDI SLAM': //CINDI SLAM
      text = user.name() + ' вдаряє рукою по ' + target.name_davalnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'CINDI COUNTER ATTACK': //CINDI COUNTER ATTACK
      text = user.name() + ' готуються!';
      break;

    //DOROTHI//
    case 'DOROTHI ATTACK': //DOROTHI ATTACK
      text = user.name() + ' топчеться по ' + target.name_davalnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'DOROTHI NOTHING': //DOROTHI NOTHING
      text = user.name() + ' плаче у темряві.';
      break;

    case 'DOROTHI KICK': //DOROTHI KICK
      text = user.name() + ' б\'є'  + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'DOROTHI HAPPY': //DOROTHI HAPPY
      text = user.name() + ' стрибає навколо!';
      break;

    //NANCI//
    case 'NANCI ATTACK': //NANCI ATTACK
      text = user.name() + ' впивається кігтями у ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'NANCI NOTHING': //NANCI NOTHING
      text = user.name() + ' хитається вперед-назад.';
      break;

    case 'NANCI ANGRY': //NANCI ANGRY
      text = user.name() + ' починає закипати!';
      break;

    //MERCI//
    case 'MERCI ATTACK': //MERCI ATTACK
      text = user.name() + ' торкається грудей ' + target.name_rodovyi() + '.\r\n';
      text += target.name() + ' відчуває, як внутрішні органи починають розриватися!\r\n';
      text += hpDamageText;
      break;

    case 'MERCI NOTHING': //MERCI NOTHING
      text = user.name() + ' моторошно всміхається.';
      break;

    case 'MERCI MELODY': //MERCI LAUGH
      text = user.name() + ' співає пісню.\r\n';
      text += target.name() + ' чує знайому мелодію.\r\n';
      if(target.isStateAffected(6)) {text += target.name() + " відчуває ЩАСТЯ!\r\n"}
      else if(target.isStateAffected(7)) {text += target.name() + " в ЕКСТАЗІ!!\r\n"}
      else if(target.isStateAffected(8)) {text += target.name() + " в МАНІЇ!!!\r\n"}
      break;

    case 'MERCI SCREAM': //MERCI SCREAM
      text = user.name() + ' моторошно кричить!\r\n';
      text += hpDamageText;
      break;


    //LILI//
    case 'LILI ATTACK': //LILI ATTACK
      text = user.name() + ' витріщається на душу ' + target.name_rodovyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'LILI NOTHING': //LILI NOTHING
      text = user.name() + ' підморгує.';
      break;

    case 'LILI MULTIPLY': //LILI MULTIPLY
      text = 'Очі ' + user.name() + ' випали!\r\n';
      text += 'Око виросло з іншого боку ' + user.name_rodovyi() + '!';
      break;

    case 'LILI CRY': //LILI CRY
      text = 'Сльози навертаються на очі ' + user.name_rodovyi() + '.\r\n';
      text += target.name() + " відчуває СУМ."
      break;

    case 'LILI SAD EYES': //LILI SAD EYES
      text = target.name() + ' бачить смуток у очах ' + user.name_rodovyi() + '\r\n';
      text += target.name() + ' неохоче починає атакувати ' + user.name_znakhidnyi(); + '.\r\n'
      break;

    //HOUSEFLY//
    case 'HOUSEFLY ATTACK': //HOUSEFLY ATTACK
      text = user.name() + ' приземлилася на обличчя ' + target.name_rodovyi() + '.\r\n';
      text += target.name() + ' шльопнув себе по обличчю!\r\n';
      text += hpDamageText;
      break;

    case 'HOUSEFLY NOTHING': //HOUSEFLY NOTHING
      text = user.name() + ' дзижчить навколо!';
      break;

    case 'HOUSEFLY ANNOY': //HOUSEFLY ANNOY
      text = user.name() + ' дзижчить біля вуха ' + target.name_rodovyi() + '!\r\n';
      if(!target._noEffectMessage) {text += target.name() + ' відчуває ЗЛІСТЬ!';}
      else {text += parseNoEffectEmotion(target.name(), "стає ЗЛІШЕ!")}
      break;

    //RECYCLIST//
    case 'FLING TRASH': //FLING TRASH
      text = user.name() + ' жбурляє СМІТТЯ в ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'GATHER TRASH': //GATHER TRASH
      text = user.name() + ' знаходить СМІТТЯ на землі\r\n';
      text += 'і змітає його до сумки!\r\n';
      text += hpDamageText;
      break;

    case 'RECYCLIST CALL FOR FRIENDS': //RECYCLIST CALL FOR FRIENDS
      text = user.name() + ' СМІТТЄПЕРЕРОБНИЙ ФАНАТИК кличе послідовників!!';
      break;

    //STRAY DOG//
    case 'STRAY DOG ATTACK': //STRAY DOG ATTACK
      text = user.name() + ' використовує кусаючу атаку!\r\n';
      text += hpDamageText;
      break;

    case 'STRAY DOG HOWL': //STRAY DOG HOWL
      text = user.name() + ' пронизливо виє!';
      break;

    //CROW//
    case 'CROW ATTACK': //CROW ATTACK
      text = user.name() + ' клює очі ' + target.name_davalnyi() + '.\r\n';
      text += hpDamageText;
      break;

    case 'CROW GRIN': //CROW GRIN
      text = user.name() + ' широко усміхається.';
      break;

    case 'CROW STEAL': //CROW STEAL
      text = user.name() + ' щось вкрала!';
      break;

    // BEE //
    case 'BEE ATTACK': //BEE Attack
      text = user.name() + ' жалить ' + target.name_znakhidnyi() + '.\r\n';
      text += hpDamageText;
      break;

    case 'BEE NOTHING': //BEE NOTHING
      text = user.name() + ' літає навколо!';
      break;

    // GHOST BUNNY //
    case 'GHOST BUNNY ATTACK': //GHOST BUNNY ATTACK
      text = user.name() + ' проходить крізь ' + target.name_znakhidnyi() + '!\r\n';
      text += target.name() + ' відчуває втому.\r\n';
      text += mpDamageText;
      break;

    case 'GHOST BUNNY NOTHING': //GHOST BUNNY DO NOTHING
      text = user.name() + ' літає на місці.';
      break;

    //TOAST GHOST//
    case 'TOAST GHOST ATTACK': //TOAST GHOST ATTACK
      text = user.name() + ' проходить крізь ' + target.name_znakhidnyi() + '!\r\n';
      text += target.name() + ' відчуває втому.\r\n';
      text += hpDamageText;
      break;

    case 'TOAST GHOST NOTHING': //TOAST GHOST NOTHING
      text = user.name() + ' видає моторошні звуки.';
      break;

    //SPROUT BUNNY//
    case 'SPROUT BUNNY ATTACK': //SPROUT BUNNY ATTACK
      text = user.name() + ' шльопає ' + target.name_znakhidnyi() + '.\r\n';
      text += hpDamageText;
      break;

    case 'SPROUT BUNNY NOTHING': //SPROUT BUNNY NOTHING
      text = user.name() + ' щипає травичку.';
      break;

    case 'SPROUT BUNNY FEED': //SPROUT BUNNY FEED
      text = user.name() + ' годує ' + target.name_znakhidnyi() + '.\r\n';
      text += `${user.name()} відновлює ${Math.abs(hpDam)} ЗДОРОВ'Я!`
      break;

    //CELERY//
    case 'CELERY ATTACK': //CELERY ATTACK
      text = user.name() + ' врізається в ' + target.name_znakhidnyi() + '.\r\n';
      text += hpDamageText;
      break;

    case 'CELERY NOTHING': //CELERY NOTHING
      text = user.name() + ' падає на землю.';
      break;

    //CILANTRO//
    case 'CILANTRO ATTACK': //CILANTRO ATTACK
      text = user.name() + ' вдаряє ' + target.name_znakhidnyi() + '.\r\n';
      text += hpDamageText;
      break;

    case 'CILANTRO NOTHING': //CILANTRO DO NOTHING
      text = user.name() + ' думає про життя.';
      break;

    case 'GARNISH': //CILANTRO GARNISH
      text = user.name() + ' жертвує собою\r\n';
      text += ' заради вдосконалення ' + target.name_rodovyi() + '.';
      break;

    //GINGER//
    case 'GINGER ATTACK': //GINGER ATTACK
      text = user.name() + ' клацає та атакує ' + target.name_znakhidnyi() + '.\r\n';
      text += hpDamageText;
      break;

    case 'GINGER NOTHING': //GINGER NOTHING
      text = user.name() + ' знаходить внутрішній спокій.';
      break;

    case 'GINGER SOOTHE': //GINGER SOOTHE
      text = user.name() + ' заспокоює ' + target.name_znakhidnyi() + '.\r\n';
      break;

    //YE OLD MOLE//
    case 'YE OLD ROLL OVER': //MEGA SPROUT MOLE ROLL OVER
      text = user.name() + ' прокочується по всім!';
      text += hpDamageText;
      break;

    //KITE KID//
    case 'KITE KID ATTACK':  // KITE KID ATTACK
      text = user.name() + ' кидає ДЖЕКС у ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'KITE KID BRAG':  // KITE KID BRAG
      text = user.name() + ' хвалиться своїм ПОВІТРЯНИМ ЗМІЄМ!\r\n';
      if(!target._noEffectMessage) {
        text += target.name() + ' відчуває ЩАСТЯ!';
      }
      else {text += parseNoEffectEmotion(target.name(), "стає ЩАСЛИВІШЕ!")}
      break;

    case 'REPAIR':  // REPAIR
      text = user.name() + ' заклеює ПОВІТРЯНОГО ЗМІЯ!\r\n';
      text += 'ПОВІТРЯНИЙ ЗМІЙ тепер як новенький!';
      break;

    //KID'S KITE//
    case 'KIDS KITE ATTACK': // KIDS KITE ATTACK
      text = user.name() + ' пірнає у ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'KITE NOTHING': // KITE NOTHING
      text = user.name() + ' гордо надуває груди!';
      break;

    case 'FLY 1':  // FLY 1
      text = user.name() + ' підлітає справді високо!';
      break;

    case 'FLY 2':  // FLY 2
      text = user.name() + ' спускається вниз!!';
      break;

    //PLUTO//
    case 'PLUTO NOTHING':  // PLUTO NOTHING
      text = user.name() + ' приймає позу!\r\n';
      break;

    case 'PLUTO HEADBUTT':  // PLUTO HEADBUTT
      text = user.name() + ' таранить лобом ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'PLUTO BRAG':  // PLUTO BRAG
      text = user.name() + ' хвалиться своїми м\'язами!\r\n';
      if(!user._noEffectMessage) {
        text += user.name() + ' відчуває ЩАСТЯ!';
      }
      else {text += parseNoEffectEmotion(user.name(), "стає ЩАСЛИВІШЕ!")}
      break;

    case 'PLUTO EXPAND':  // PLUTO EXPAND
      text = user.name() + ' підкачує себе!!\r\n';
      if(!target._noStateMessage) {
        text += 'АТАКА і ЗАХИСТ ' + user.name_rodovyi() + 'А підвищились!!\r\n';
        text += 'ШВИДКІСТЬ ' + user.name_rodovyi() + 'А знизилася.';
      }
      else {
        text += parseNoStateChange("АТАКА", user.name_rodovyi(), "стала вище!\r\n")
        text += parseNoStateChange("ЗАХИСТ", user.name_rodovyi(), "став вище!\r\n")
        text += parseNoStateChange("ШВИДКІСТЬ", user.name_rodovyi(), "стала нижче!")
      }
      break;

    case 'EXPAND NOTHING':  // PLUTO NOTHING
      text = 'М\'язи ' + user.name_rodovyi();
      text += 'залякують команду.';
      break;

    //RIGHT ARM//
    case 'R ARM ATTACK':  // R ARM ATTACK
      text = user.name() + ' відбиває ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'GRAB':  // GRAB
      text = user.name() + ' хапає ' + target.name_znakhidnyi() + '!\r\n';
      text += 'ШВИДКІСТЬ ' + target.name_rodovyi() + ' знизилася.\r\n';
      text += hpDamageText;
      break;

    //LEFT ARM//
    case 'L ARM ATTACK':  // L ARM ATTACK
      text = user.name() + ' б\'є ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'POKE':  // POKE
      text = user.name() + ' тицяє у ' + target.name_znakhidnyi() + '!\r\n';
      if(!target._noEffectMessage) {
        text += target.name() + ' відчуває ЗЛІСТЬ!\r\n';
      }
      else {text += parseNoEffectEmotion(target.name(), "стає ЗЛІШЕ!\r\n")}
      text += hpDamageText;
      break;

    //DOWNLOAD WINDOW//
    case 'DL DO NOTHING':  // DL DO NOTHING
      text = user.name() + ' завантажено на 99%.';
      break;

    case 'DL DO NOTHING 2':  // DL DO NOTHING 2
      text = user.name() + ' досі';
      text += 'завантажено на 99%...';
      break;

    case 'DOWNLOAD ATTACK':  // DOWNLOAD ATTACK
      text = user.name() + ' ламається і горить!';
      break;

    //SPACE EX-BOYFRIEND//
    case 'SXBF ATTACK':  // SXBF ATTACK
      text = user.name() + ' б\'є ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'SXBF NOTHING':  // SXBF NOTHING
      text = user.name() + ' задумливо\r\n';
      text += ' дивиться у далечінь.';
      break;

    case 'ANGRY SONG':  // ANGRY SONG
      text = user.name() + ' інтенсивно виє!';
      break;

    case 'ANGSTY SONG':  // ANGSTY SONG
      text = user.name() + ' сумно співає...\r\n';
      if(target.isStateAffected(10)) {text += target.name() + ' відчуває СУМ.';}
      else if(target.isStateAffected(11)) {text += target.name() + ' в ЖУРБІ..';}
      else if(target.isStateAffected(12)) {text += target.name() + ' у БЕЗНАДІЇ...';}
      break;

    case 'BIG LASER':  // BIG LASER
      text = user.name() + ' стріляє лазером!\r\n';
      text += hpDamageText;
      break;

    case 'BULLET HELL':  // BULLET HELL
      text = user.name() + ' стріляє своїм\r\n';
      text += 'лазером дико та у розпачі!';
      break;

    case 'SXBF DESPERATE':  // SXBF NOTHING
      text = user.name() + '\r\n';
      text += 'зціпив зуби!';
      break;

    //THE EARTH//
    case 'EARTH ATTACK':  // EARTH ATTACK
      text = user.name() + ' атакує ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText
      break;

    case 'EARTH NOTHING':  // EARTH NOTHING
      text = user.name() + ' повільно обертається.';
      break;

    case 'EARTH CRUEL':  // EARTH CRUEL
      text = user.name() + ' жорстока до ' + target.name_rodovyi() + '!\r\n';
      if(target.isStateAffected(10)) {text += target.name() + ' відчуває СУМ.';}
      else if(target.isStateAffected(11)) {text += target.name() + ' в ЖУРБІ..';}
      else if(target.isStateAffected(12)) {text += target.name() + ' у БЕЗНАДІЇ...';}
      break;

    case 'CRUEL EPILOGUE':  // EARTH CRUEL
      if(target.index() <= unitLowestIndex) {
        text = user.name() + " жорстока до всіх...\r\n";
        text += "Усі відчувають СУМ."
      }
      break;

    case 'PROTECT THE EARTH':  // PROTECT THE EARTH
      text = user.name() + ' використовує найсильнішу атаку!';
      break;

    //SPACE BOYFRIEND//
    case 'SBF ATTACK': //SPACE BOYFRIEND ATTACK
      text = user.name() + ' швидко б\'є ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'SBF LASER': //SPACE BOYFRIEND LASER
      text = user.name() + ' стріляє лазером!\r\n';
      text += hpDamageText;
      break;

    case 'SBF CALM DOWN': //SPACE BOYFRIEND CALM DOWN
      text = user.name() + ' спустошує свій розум\r\n';
      text += 'і прибирає всі ЕМОЦІЇ.';
      break;

    case 'SBF ANGRY SONG': //SPACE BOYFRIEND ANGRY SONG
      if(target.index() <= unitLowestIndex) {
        text = user.name() + ' реве у гніві!\r\n';
        text += "Усі відчувають ЗЛІСТЬ!\r\n";
      }
      text += hpDamageText;
      break;

    case 'SBF ANGSTY SONG': //SPACE BOYFRIEND ANGSTY SONG
      if(target.index() <= unitLowestIndex) {
        text = user.name() + ' співає разом із темрявою\r\n';
        text += 'у своїй душі!\r\n';
        text += "Усі відчувають СУМ.\r\n";
      }
      text += mpDamageText;
      break;

    case 'SBF JOYFUL SONG': //SPACE BOYFRIEND JOYFUL SONG
      if(target.index() <= unitLowestIndex) {
        text = user.name() + ' співає зі всією радістю\r\n';
        text += "у своїй душі!\r\n"
        text += "Усі відчувають ЩАСТЯ!\r\n";
      }
      text += hpDamageText;
      break;

    //NEFARIOUS CHIP//
    case 'EVIL CHIP ATTACK': //NEFARIOUS CHIP ATTACK
      text = user.name() + ' заряджає у ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'EVIL CHIP NOTHING': //NEFARIOUS CHIP NOTHING
      text = user.name() + ' гладить свої злі\r\n';
      text += 'вуса!';
      break;


    case 'EVIL LAUGH': //NEFARIOUS LAUGH
      text = user.name() + ' злісно сміється\r\n';
      text += 'бо він лиходій!\r\n';
      if(!target._noEffectMessage) {text += target.name() + " відчуває ЩАСТЯ!"}
      else {text += parseNoEffectEmotion(target.name(), "стає ЩАСЛИВІШЕ!")}
      break;

    case 'EVIL COOKIES': //NEFARIOUS COOKIES
      text = user.name() + ' кидається ВІВСЯНИМ ПЕЧИВОМ у всіх!\r\n';
      text += 'Як по-злому!';
      break;

    //BISCUIT AND DOUGHIE//
    case 'BD ATTACK': //BISCUIT AND DOUGHIE ATTACK
      text = user.name() + ' разом атакують!\r\n';
      text += hpDamageText;
      break;

    case 'BD NOTHING': //BISCUIT AND DOUGHIE NOTHING
      text = user.name() + ' щось забули в печі!\r\n';
      break;

    case 'BD BAKE BREAD': //BISCUIT AND DOUGHIE BAKE BREAD
      text = user.name() + ' витягують ХЛІБ із печі!\r\n';
      break;

    case 'BD COOK': //BISCUIT AND DOUGHIE CHEER UP
      text = user.name() + ' роблять печиво!\r\n';
      text += `${target.name()} відновлюють ${Math.abs(hpDam)}\r\nЗДОРОВ'Я!`
      break;

    case 'BD CHEER UP': //BISCUIT AND DOUGHIE CHEER UP
      text = user.name() + ' роблять все можливе, аби\r\n';
      text += 'не бути СУМНИМИ.';
      break;

    //KING CRAWLER//
    case 'KC ATTACK': //KING CRAWLER ATTACK
      text = user.name() + ' врізається у ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'KC NOTHING': //KING CRAWLER NOTHING
      text = user.name() + ' випускає пронизливий\r\n';
      text += 'вереск!\r\n';
      if(!target._noEffectMessage) {
        text += target.name() + " відчуває ЗЛІСТЬ!";
      }
      else {text += parseNoEffectEmotion(target.name(), "стає ЗЛІШЕ!")}
      break;

    case 'KC CONSUME': //KING CRAWLER CONSUME
      text = user.name() + ' з\'їв\r\n';
      text += "ЗАГУБЛЕНОГО КРОТО-ПАРОСТКА!\r\n"
      text += `${target.name()} відновлює ${Math.abs(hpDam)} ЗДОРОВ'Я!\r\n`;
      break;

    case 'KC RECOVER': //KING CRAWLER CONSUME
      text = `${target.name()} відновлює ${Math.abs(hpDam)} ЗДОРОВ'Я!\r\n`;
      if(!target._noEffectMessage) {text += target.name() + " відчуває ЩАСТЯ!"}
      else {text += parseNoEffectEmotion(target.name(), "стає ЩАСЛИВІШЕ!")}
      break;

    case 'KC CRUNCH': //KING CRAWLER CRUNCH
      text = user.name() + ' кусає ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'KC RAM': //KING CRAWLER RAM
      text = user.name() + ' проповзає крізь команду!\r\n';
      text += hpDamageText;
      break;

    //KING CARNIVORE//

    case "SWEET GAS":
      if(target.index() <= unitLowestIndex) {
        text = user.name() + " випускає газ!\r\n";
        text += "Солодко пахне!\r\n";
        text += "Усі відчувають ЩАСТЯ!";
      }
      target._noEffectMessage = undefined;
      break;

    //SPROUTMOLE LADDER//
    case 'SML NOTHING': //SPROUT MOLE LADDER NOTHING
      text = user.name() + ' міцно стоїть на місці. ';
      break;

    case 'SML SUMMON MOLE': //SPROUT MOLE LADDER SUMMON SPROUT MOLE
      text = 'КРОТО-ПАРОСТОК лізе нагору ' + user.name_rodovyi() + '!';
      break;

    case 'SML REPAIR': //SPROUT MOLE LADDER REPAIR
      text = user.name() + ' було відремонтовано.';
      break;

    //UGLY PLANT CREATURE//
    case 'UPC ATTACK': //UGLY PLANT CREATURE ATTACK
      text = user.name() + ' огортає\r\n';
      text += target.name_znakhidnyi() + ' виноградною лозою!\r\n';
      text += hpDamageText;
      break;

    case 'UPC NOTHING': //UGLY PLANT CRATURE NOTHING
      text = user.name() + ' ричить!';
      break;

    //ROOTS//
    case 'ROOTS NOTHING': //ROOTS NOTHING
      text = user.name() + ' хитається навколо.';
      break;

    case 'ROOTS HEAL': //ROOTS HEAL
      text = user.name() + ' забезпечує поживними речовинами\r\n';
      text += target.name() + '.';
      break;

    //BANDITO MOLE//
    case 'BANDITO ATTACK': //BANDITO ATTACK
      text = user.name() + ' ріже ' + target.name_znakhidnyi() + '!\r\n';
      text += hpDamageText;
      break;

    case 'BANDITO STEAL': //BANDITO STEAL
      text = user.name() + 'швидко краде річ у\r\n';
      text += 'команди!'
      break;

    case 'B.E.D.': //B.E.D.
      text = user.name() + ' витягує Л.І.Ж.К.О.!\r\n';
      text += hpDamageText;
      break;

    //SIR MAXIMUS//
    case 'MAX ATTACK': //SIR MAXIMUS ATTACK
      text = user.name() + ' замахується мечем!\r\n';
      text += hpDamageText;
      break;

    case 'MAX NOTHING': //SIR MAXIMUS NOTHING
      text = user.name() + ' потягнув спину...\r\n';
      if(!target._noEffectMessage) {
        text += target.name() + ' відчуває СУМ.'
      }
      else {text += parseNoEffectEmotion(target.name(), "стає СУМНІШЕ!")}
      break;

    case 'MAX STRIKE': //SIR MAXIMUS SWIFT STRIKE
      text = user.name() + ' вдаряє двічі!';
      break;

    case 'MAX ULTIMATE ATTACK': //SIR MAXIMUS ULTIMATE ATTACK
      text = '"ЧАС ДЛЯ МОЄЇ ФІНАЛЬНОЇ АТАКИ!"';
      text += hpDamageText;
      break;

    case 'MAX SPIN': //SIR MAXIMUS SPIN
        break;

    //SIR MAXIMUS II//
    case 'MAX 2 NOTHING': //SIR MAXIMUS II NOTHING
      text = user.name() + ' згадує батькові\r\n';
      text += 'останні слова.\r\n';
      if(!target._noEffectMessage) {
        text += target.name() + ' відчуває СУМ.'
      }
      else {text += parseNoEffectEmotion(target.name(), "стає СУМНІШЕ!")}
      break;

    //SIR MAXIMUS III//
    case 'MAX 3 NOTHING': //SIR MAXIMUS III NOTHING
      text = user.name() + ' згадує дідусеві\r\n';
      text += 'останні слова.\r\n';
      text += target.name() + ' відчуває СУМ.'
      break;

    //SWEETHEART//
    case 'SH ATTACK': //SWEET HEART ATTACK
      text = user.name() + ' шльопає ' + target.name_znakhidnyi() + '.\r\n';
      text += hpDamageText;
      break;

    case 'SH INSULT': //SWEET HEART INSULT
      if(target.index() <= unitLowestIndex) {
        text = user.name() + " ображає всіх!\r\n"
        text += "Усі відчувають ЗЛІСТЬ!\r\n";
      }
      text += hpDamageText;
      target._noEffectMessage = undefined;
      break;

    case 'SH SNACK': //SWEET HEART SNACK
      text = user.name() + ' наказує підлеглому принести їй\r\n';
      text += 'ПЕРЕКУС.\r\n';
      text += hpDamageText;
      break;

    case 'SH SWING MACE': //SWEET HEART SWING MACE
      text = user.name() + ' із завзяттям розмахує булавою!\r\n';
      text += hpDamageText;
      break;

    case 'SH BRAG': //SWEET HEART BRAG
      text = user.name() + ' хвалиться про\r\n';
      text += 'один із своїх багатьох талантів!\r\n';
      if(!target._noEffectMessage) {
        if(target.isStateAffected(8)) {text += target.name() + ' в МАНІЇ!!!';}
        else if(target.isStateAffected(7)) {text += target.name() + ' в ЕКСТАЗІ!!';}
        else if(target.isStateAffected(6)) {text += target.name() + ' відчуває ЩАСТЯ!';}
      }
      else {text += parseNoEffectEmotion(target.name(), "стає ЩАСЛИВІШЕ!")}

      break;

      //MR. JAWSUM //
      case 'DESK SUMMON MINION': //MR. JAWSUM DESK SUMMON MINION
        text = user.name() + ' бере телефон та\r\n';
        text += 'телефонує КРОКОДИЛЕРУ!';
        break;

      case 'JAWSUM ATTACK ORDER': //MR. JAWSUM DESK ATTACK ORDER
        if(target.index() <= unitLowestIndex) {
          text = user.name() + ' наказує атакувати!\r\n';
          text += "Усі відчувають ЗЛІСТЬ!";
        }
        break;

      case 'DESK NOTHING': //MR. JAWSUM DESK DO NOTHING
        text = user.name() + ' починає рахувати МУШЛІ.';
        break;

      //PLUTO EXPANDED//
      case 'EXPANDED ATTACK': //PLUTO EXPANDED ATTACK
        text = user.name() + ' жбурляє Місяць у\r\n';
        text += target.name() + '!\r\n';
        text += hpDamageText;
        break;

      case 'EXPANDED SUBMISSION HOLD': //PLUTO EXPANDED SUBMISSION HOLD
        text = user.name() + ' тримає ' + target.name_znakhidnyi() + '\r\n';
        text += 'всіх у покорі!\r\n';
        text += 'ШВИДКІСТЬ ' + target.name_rodovyi() + ' знизилася.\r\n';
        text += hpDamageText;
        break;

      case 'EXPANDED HEADBUTT': //PLUTO EXPANDED HEADBUTT
        text = user.name() + ' вдаряється головою\r\n';
        text += 'в ' +  target.name_znakhidnyi() + '!\r\n';
        text += hpDamageText;
        break;

      case 'EXPANDED FLEX COUNTER': //PLUTO EXPANDED FLEX COUNTER
        text = user.name() + ' розтягує свої м’язи та\r\n'
        text += 'готується!';
        break;

      case 'EXPANDED EXPAND FURTHER': //PLUTO EXPANDED EXPAND FURTHER
        text = user.name() + ' ще більше розширюється!\r\n';
        if(!target._noStateMessage) {
          text += 'АТАКА ' + target.name_rodovyi() + ' підвищилася!\r\n';
          text += 'ЗАХИСТ ' + target.name_rodovyi() + ' підвищився!\r\n';
          text += 'ШВИДКІСТЬ ' + target.name_rodovyi() + ' знизилася.';
        }
        else {
          text += parseNoStateChange("АТАКА", user.name_rodovyi(), "стала вище!\r\n")
          text += parseNoStateChange("ЗАХИСТ", user.name_rodovyi(), "став вище!\r\n")
          text += parseNoStateChange("ШВИДКІСТЬ", user.name_rodovyi(), "стала нижче!")
        }
        break;

      case 'EXPANDED EARTH SLAM': //PLUTO EXPANDED EARTH SLAM
        text = user.name() + ' підіймає Землю\r\n';
        text += 'та гупає нею всіх підряд!';
        break;

      case 'EXPANDED ADMIRATION': //PLUTO EXPANDED ADMIRATION
        text = user.name() + ' захоплюється прогресом КЕЛА!\r\n';
        if(target.isStateAffected(8)) {text += target.name() + ' в МАНІЇ!!!';}
        else if(target.isStateAffected(7)) {text += target.name() + ' в ЕКСТАЗІ!!';}
        else if(target.isStateAffected(6)) {text += target.name() + ' відчуває ЩАСТЯ!';}
        break;

      //ABBI TENTACLE//
      case 'TENTACLE ATTACK': //ABBI TENTACLE ATTACK
        text = user.name() + ' ударяє ' + target.name_znakhidnyi() + '!\r\n';
        text += hpDamageText;
        break;

      case 'TENTACLE TICKLE': //ABBI TENTACLE TICKLE
        text = user.name() + " послаблює " + target.name_znakhidnyi() + "!\r\n";
        var pronumn = target.name() === $gameActors.actor(2).name() ? "її" : "його";
        text += `${target.name()} ${pronumn} пильність зменшилася!`
        break;

      case 'TENTACLE GRAB': //ABBI TENTACLE GRAB
        text = user.name() + ' огортається навколо ' + target.name_rodovyi() + '!\r\n';
        if(result.isHit()) {
          if(target.name() !== "ОМОРІ" && !target._noEffectMessage) {text += target.name() + " у ЖАХУ.\r\n";}
          else {text += parseNoEffectEmotion(target.name(), "відуває ЖАХ")}
        }
        text += hpDamageText;
        break;

      case 'TENTACLE GOOP': //ABBI TENTACLE GOOP
        text = target.name() + ' просякнуте темною рідиною!\r\n';
        text += target.name() + ' відчуває слабкість...\r\n';
        text += 'АТАКА ' + target.name_rodovyi() + ' знизилася.\r\n';
        text += 'ЗАХИСТ ' + target.name_rodovyi() + ' знизився.\r\n';
        text += 'ШВИДКІСТЬ ' + target.name_rodovyi() + ' знизилася.';
        break;

      //ABBI//
      case 'ABBI ATTACK': //ABBI ATTACK
        text = user.name() + ' атакує ' + target.name_znakhidnyi() + '!\r\n';
        text += hpDamageText;
        break;

      case 'ABBI REVIVE TENTACLE': //ABBI REVIVE TENTACLE
        text = user.name() + ' зосереджується на своєму ЗДОРОВ\'Ї.';
        break;

      case 'ABBI VANISH': //ABBI VANISH
        text = user.name() + ' зникає у тінях...';
        break;

      case 'ABBI ATTACK ORDER': //ABBI ATTACK ORDER
        if(target.index() <= unitLowestIndex) {
          text = user.name() + ' розтягує свої щупальця.\r\n';
          text += "У всіх підвищилася АТАКА!!\r\n"
          text += "Усі відчувають ЗЛІСТЬ!"
        }
        break;

      case 'ABBI COUNTER TENTACLE': //ABBI COUNTER TENTACLES
        text = user.name() + ' рухається крізь тіні...';
        break;

      //ROBO HEART//
      case 'ROBO HEART ATTACK': //ROBO HEART ATTACK
        text = user.name() + ' стріляє ракетами з рук!\r\n';
        text += hpDamageText;
        break;

      case 'ROBO HEART NOTHING': //ROBO HEART NOTHING
        text = user.name() + ' завантажується...';
        break;

      case 'ROBO HEART LASER': //ROBO HEART LASER
        text = user.name() + ' відкриває свій рот та\r\n';
        text += 'стріляє лазером!\r\n';
        text += hpDamageText;
        break;

      case 'ROBO HEART EXPLOSION': //ROBO HEART EXPLOSION
        text = user.name() + ' пускає скупу сльозу робота.\r\n';
        text += user.name() + ' вибухає!';
        break;

      case 'ROBO HEART SNACK': //ROBO HEART SNACK
        text = user.name() + ' відкриває свого рота.\r\n';
        text += 'З’являється поживний ПЕРЕКУС!\r\n';
        text += hpDamageText;
        break;

      //MUTANT HEART//
      case 'MUTANT HEART ATTACK': //MUTANT HEART ATTACK
        text = user.name() + ' співає пісню для ' + target.name_rodovyi() + '!\r\n';
        text += 'Це було не найприємніше...\r\n';
        text += hpDamageText;
        break;

      case 'MUTANT HEART NOTHING': //MUTANT HEART NOTHING
        text = user.name() + ' позує!';
        break;

      case 'MUTANT HEART HEAL': //MUTANT HEART HEAL
        text = user.name() + ' зашиває свою сукню!';
        text += hpDamageText;
        break;

      case 'MUTANT HEART WINK': //MUTANT HEART WINK
        text = user.name() + ' підморгує ' + target.name_davalnyi() + '!\r\n';
        text += 'Це було трохи мило...\r\n';
        if(!target._noEffectMessage){text += target.name() + ' відчуває ЩАСТЯ!';}
        else {text += parseNoEffectEmotion(target.name(), "стає ЩАСЛИВІШЕ!")}
        break;

      case 'MUTANT HEART INSULT': //MUTANT HEART INSULT
        text = user.name() + ' випадково ляпнула\r\n';
        text += 'щось злісне.\r\n';
        if(!target._noEffectMessage){text += target.name() + ' відчуває ЗЛІСТЬ!';}
        else {text += parseNoEffectEmotion(target.name(), "стає ЗЛІШЕ!")}
        break;

      case 'MUTANT HEART KILL': //MUTANT HEART KILL
        text = 'МУТАНТОСЕРДЕНЬКА ляскає ' + user.name() +'!\r\n';
        text += hpDamageText;
        break;

        //PERFECT HEART//
        case 'PERFECT STEAL HEART': //PERFECT HEART STEAL HEART
          text = user.name() + ' краде у ' + target.name_rodovyi() + '\r\n';
          text += 'ЗДОРОВ\'Я.\r\n';
          text += hpDamageText + "\r\n";
          if(user.result().hpDamage < 0) {text += `${user.name()} відновлює ${Math.abs(user.result().hpDamage)} ЗДОРОВ'Я!\r\n`}
          break;

        case 'PERFECT STEAL BREATH': //PERFECT HEART STEAL BREATH
          text = user.name() + ' краде у ' + target.name_rodovyi() + '\r\n';
          text += 'дихання.\r\n';
          text += mpDamageText + "\r\n";
          if(user.result().mpDamage < 0) {text += `${user.name()} відновлює ${Math.abs(user.result().mpDamage)} СОКУ...\r\n`}
          break;

        case 'PERFECT EXPLOIT EMOTION': //PERFECT HEART EXPLOIT EMOTION
          text = user.name() + ' використовує ЕМОЦІЇ ' + target.name_rodovyi() + '!\r\n';
          text += hpDamageText;
          break;

        case 'PERFECT SPARE': //PERFECT SPARE
          text = user.name() + ' вирішує залишити\r\n';
          text += target.name() + ' в живих.\r\n';
          text += hpDamageText;
          break;

        case 'PERFECT ANGELIC VOICE': //UPLIFTING HYMN
          if(target.index() <= unitLowestIndex) {
            text = user.name() + ' співає душевну пісню...\r\n';
            if(!user._noEffectMessage) {text += user.name() + " відчуває СУМ.\r\n"}
            else {text += parseNoEffectEmotion(user.name(), "стає СУМНІШЕ!\r\n")}
            text += 'Всі почуваються ЩАСЛИВИМИ!';
          }
          break;

        case "PERFECT ANGELIC WRATH":
          if(target.index() <= unitLowestIndex) {text = user.name() + " випускає свій гнів.\r\n";}
          if(!target._noEffectMessage) {
              if(target.isStateAffected(8)) {text += target.name() + ' в МАНІЇ!!!\r\n';}
              else if(target.isStateAffected(7)) {text += target.name() + ' в ЕКСТАЗІ!!\r\n';}
              else if(target.isStateAffected(6)) {text += target.name() + ' відчуває ЩАСТЯ!\r\n';}
              else if(target.isStateAffected(12)) {text += target.name() + ' у БЕЗНАДІЇ...\r\n';}
              else if(target.isStateAffected(11)) {text += target.name() + ' в ЖУРБІ..\r\n';}
              else if(target.isStateAffected(10)) {text += target.name() + ' відчуває СУМ.\r\n';}
              else if(target.isStateAffected(12)) {text += target.name() + ' СКАЖЕНІЄ!!!\r\n';}
              else if(target.isStateAffected(11)) {text += target.name() + ' відчуває ЛЮТЬ!! \r\n';}
              else if(target.isStateAffected(10)) {text += target.name() + ' відчуває ЗЛІСТЬ!\r\n';}
          }
          else {
            if(target.isEmotionAffected("happy")) {text += parseNoEffectEmotion(target.name(), "стає ЩАСЛИВІШЕ!\r\n")}
            else if(target.isEmotionAffected("sad")) {text += parseNoEffectEmotion(target.name(), "стає СУМНІШЕ!\r\n")}
            else if(target.isEmotionAffected("angry")) {text += parseNoEffectEmotion(target.name(), "стає ЗЛІШЕ!\r\n")}
          }
          text += hpDamageText;
          break;

        //SLIME GIRLS//
        case 'SLIME GIRLS COMBO ATTACK': //SLIME GIRLS COMBO ATTACK
          text = user.name() + ' атакують всі водночас!\r\n';
          text += hpDamageText;
          break;

        case 'SLIME GIRLS DO NOTHING': //SLIME GIRLS DO NOTHING
          text = 'МЕДУЗА жбурляє пляшку...\r\n';
          text += 'Але нічого не відбулося...';
          break;

        case 'SLIME GIRLS STRANGE GAS': //SLIME GIRLS STRANGE GAS
            if(!target._noEffectMessage) {
              if(target.isStateAffected(8)) {text += target.name() + ' в МАНІЇ!!!\r\n';}
              else if(target.isStateAffected(7)) {text += target.name() + ' в ЕКСТАЗІ!!\r\n';}
              else if(target.isStateAffected(6)) {text += target.name() + ' відчуває ЩАСТЯ!\r\n';}
              else if(target.isStateAffected(12)) {text += target.name() + ' у БЕЗНАДІЇ...\r\n';}
              else if(target.isStateAffected(11)) {text += target.name() + ' в ЖУРБІ..\r\n';}
              else if(target.isStateAffected(10)) {text += target.name() + ' відчуває СУМ.\r\n';}
              else if(target.isStateAffected(16)) {text += target.name() + ' СКАЖЕНІЄ!!!\r\n';}
              else if(target.isStateAffected(15)) {text += target.name() + ' відчуває ЛЮТЬ!!\r\n';}
              else if(target.isStateAffected(14)) {text += target.name() + ' відчуває ЗЛІСТЬ!\r\n';}
          }
          else {
            if(target.isEmotionAffected("happy")) {text += parseNoEffectEmotion(target.name(), "стає ЩАСЛИВІШЕ!\r\n")}
            else if(target.isEmotionAffected("sad")) {text += parseNoEffectEmotion(target.name(), "стає СУМНІШЕ!\r\n")}
            else if(target.isEmotionAffected("angry")) {text += parseNoEffectEmotion(target.name(), "стає ЗЛІШЕ!\r\n")}
          }
          break;

        case 'SLIME GIRLS DYNAMITE': //SLIME GIRLS DYNAMITE
          //text = 'МЕДУЗА жбурнула пляшку...\r\n';
          //text += 'Вона вибухає!\r\n';
          text += hpDamageText;
          break;

        case 'SLIME GIRLS STING RAY': //SLIME GIRLS STING RAY
          text = 'МОЛЛІ стріляє жалами!\r\n';
          text += 'Вони влучають у ' + target.name_znakhidnyi() + '!\r\n';
          text += hpDamageText;
          break;

        case 'SLIME GIRLS SWAP': //SLIME GIRLS SWAP
          text = 'МЕДУЗА щось зробила!\r\n';
          text += 'Твої ЗДОРОВ\'Я та СІК помінялися місцями!';
          break;

        case 'SLIME GIRLS CHAIN SAW': //SLIME GIRLS CHAIN SAW
          text = 'МАРИНА витягає бензопилу!\r\n';
          text += hpDamageText;
          break;

      //HUMPHREY SWARM//
      case 'H SWARM ATTACK': //HUMPHREY SWARM ATTACK
        text = 'ГАМФРІ оточив і атакує ' + target.name_znakhidnyi() + '!\r\n';
        text += hpDamageText;
        break;

      //HUMPHREY LARGE//
      case 'H LARGE ATTACK': //HUMPHREY LARGE ATTACK
        text = 'ГАМФРІ вдаряється у ' + target.name_znakhidnyi() + '!\r\n';
        text += hpDamageText;
        break;

      //HUMPHREY FACE//
      case 'H FACE CHOMP': //HUMPHREY FACE CHOMP
        text = 'ГАМФРІ впивається своїми зубами у ' + target.name_znakhidnyi() + '!\r\n';
        text += hpDamageText;
        break;

      case 'H FACE DO NOTHING': //HUMPHREY FACE DO NOTHING
        text = 'ГАМФРІ витріщається на ' + target.name_znakhidnyi() + '!\r\n';
        text += 'Рот ГАМФРІ безперервно наповнюється слиною.';
        break;

      case 'H FACE HEAL': //HUMPHREY FACE HEAL
        text = 'ГАМФРІ проковтнув ворога!\r\n';
        text += `ГАМФРІ відновлює ${Math.abs(hpDam)} ЗДОРОВ'Я!`
        break;

      //HUMPHREY UVULA//
      case 'UVULA DO NOTHING 1': //HUMPHREY UVULA DO NOTHING
        text = user.name() + ' усміхається до ' + target.name_rodovyi() + '.\r\n';
      break;

      case 'UVULA DO NOTHING 2': //HUMPHREY UVULA DO NOTHING
      text = user.name() + ' підморгує ' + target.name_davalnyi() + '.\r\n';
      break;

      case 'UVULA DO NOTHING 3': //HUMPHREY UVULA DO NOTHING
      text = user.name() + ' слюнявить ' + target.name_znakhidnyi() + '.\r\n';
      break;

      case 'UVULA DO NOTHING 4': //HUMPHREY UVULA DO NOTHING
      text = user.name() + ' витріщається на ' + target.name_znakhidnyi() + '.\r\n';
      break;

      case 'UVULA DO NOTHING 5': //HUMPHREY UVULA DO NOTHING
      text = user.name() + ' блимає очима на ' + target.name_znakhidnyi() + '.\r\n';
      break;

      //FEAR OF FALLING//
      case 'DARK NOTHING': //SOMETHING IN THE DARK NOTHING
        text = user.name() + ' насміхається над ' + target.name_orudnyi() + ',\r\n';
        text += 'коли падає.';
        break;

      case 'DARK ATTACK': //SOMETHING IN THE DARK ATTACK
        text = user.name() + ' штовхає ' + target.name_znakhidnyi() + '.\r\n';
        text += hpDamageText;
        break;

      //FEAR OF BUGS//
      case 'BUGS ATTACK': //FEAR OF BUGS ATTACK
        text = user.name() + ' кусає ' + target.name_znakhidnyi() + '!\r\n';
        text += hpDamageText;
        break;

      case 'BUGS NOTHING': //FEAR OF BUGS NOTHING
        text = user.name() + ' намагається поспілкуватися з тобою...';
        break;

      case 'SUMMON BABY SPIDER': //SUMMON BABY SPIDER
        text = 'Павук починає вилуплятись.\r\n';
        text += 'З\'явився ПАВУК-МАЛЮК.';
        break;

      case 'BUGS SPIDER WEBS': //FEAR OF BUGS SPIDER WEBS
        text = user.name() + ' обплутує ' + target.name_znakhidnyi() + '\r\n';
        text += 'у липку павутину.\r\n';
        text += 'ШВИДКІСТЬ ' + target.name_rodovyi() + ' знизилася!\r\n';
        break;

      //BABY SPIDER//
      case 'BABY SPIDER ATTACK': //BABY SPIDER ATTACK
        text = user.name() + ' кусає ' + target.name_znakhidnyi() + '!\r\n';
        text += hpDamageText;
        break;

      case 'BABY SPIDER NOTHING': //BABY SPIDER NOTHING
        text = user.name() + ' видає дивний звук.';
        break;

      //FEAR OF DROWNING//
      case 'DROWNING ATTACK': //FEAR OF DROWNING ATTACK
        text = 'Вода тягне ' + target.name() + ' у різні боки.\r\n';
        text += hpDamageText;
        break;

      case 'DROWNING NOTHING': //FEAR OF DROWNING NOTHING
        text = user.name() + ' чує звуки боротьби ' + target.name_rodovyi() + ".";
        break;

      case 'DROWNING DRAG DOWN': //FEAR OF DROWNING DRAG DOWN
        // text = user.name() + ' хапає ногу\r\n';
        // text += target.name() + ' та тягне до дна!\r\n';
        text = hpDamageText;
        break;

      //OMORI'S SOMETHING//
      case 'O SOMETHING ATTACK': //OMORI SOMETHING ATTACK
        text = user.name() + ' проходить крізь ' + target.name_znakhidnyi() + '.\r\n';
        text += hpDamageText;
        break;

      case 'O SOMETHING NOTHING': //OMORI SOMETHING NOTHING
        text = user.name() + ' дивиться крізь ' + target.name_znakhidnyi() + '.\r\n';
        break;

      case 'O SOMETHING BLACK SPACE': //OMORI SOMETHING BLACK SPACE
        //text = user.name() + ' тягне ' + target.name() + ' у\r\n';
        //text += 'темряву.';
        text = hpDamageText;
        break;

      case 'O SOMETHING SUMMON': //OMORI SOMETHING SUMMON SOMETHING
        text = user.name() + ' кличе щось із \r\n';
        text += 'темряви.';
        break;

      case 'O SOMETHING RANDOM EMOTION': //OMORI SOMETHING RANDOM EMOTION
        text = user.name() + ' грається з ЕМОЦІЯМИ ' + target.name_rodovyi() + '.';
        break;

      //BLURRY IMAGE//
      case 'BLURRY NOTHING': //BLURRY IMAGE NOTHING
        text = 'ЩОСЬ колихається на вітрі.';
        break;

      //HANGING BODY//
      case 'HANG WARNING':
          text = 'Ти відчуваєш, як сироти пробігли по спині.';
          break;

      case 'HANG NOTHING 1':
          text = 'Тобі паморочиться в голові.';
          break;

      case 'HANG NOTHING 2':
          text = 'Ти відчуваєш, як легені стиснулись.';
          break;

      case 'HANG NOTHING 3':
          text = 'Ти відчуваєш як втискається твій\r\n';
          text += 'шлунок.';
          break;

      case 'HANG NOTHING 4':
          text = 'Ти відчуваєш, як серце вистрибує з\r\n';
          text += 'твоїх грудей.';
          break;

      case 'HANG NOTHING 5':
          text = 'Ти тремтиш.';
          break;

      case 'HANG NOTHING 6':
          text = 'Ти відчуваєш слабкість у колінах.';
          break;

      case 'HANG NOTHING 7':
          text = 'Ти відчуваєш, як краплини поту стікають\r\n';
          text += 'з лоба.';
          break;

      case 'HANG NOTHING 8':
          text = 'Ти відчуваєш, як кулаки стискаються самі по собі.';
          break;

      case 'HANG NOTHING 9':
          text = 'Ти чуєш своє серцебиття.';
          break;

      case 'HANG NOTHING 10':
          text = 'Ти чуєш, як серцебиття стабілізується.';
          break;

      case 'HANG NOTHING 11':
          text = 'Ти чуєш, як твоє дихання вирівнюється.';
          break;

      case 'HANG NOTHING 12':
          text = 'Ти зосереджуєшся на тому, що прямо\r\n';
          text += 'перед тобою.';
          break;

      //AUBREY//
      case 'AUBREY NOTHING': //AUBREY NOTHING
        text = user.name() + ' плює тобі під ноги.';
        break;

      case 'AUBREY TAUNT': //AUBREY TAUNT
        text = user.name() + ' обзиває ' + target.name_znakhidnyi() + ' слабким!\r\n';
        text += target.name() + " відчуває ЗЛІСТЬ!";
        break;

      //THE HOOLIGANS//
      case 'CHARLIE ATTACK': //HOOLIGANS CHARLIE ATTACK
        text = 'ЧАРЛІ викладається на повну і атакує!\r\n';
        text += hpDamageText;
        break;

      case 'ANGEL ATTACK': //HOOLIGANS ANGEL ATTACK
        text = 'ЕНДЖЕЛ стрімко завдає удару ' + target.name_davalnyi() + '!\r\n';
        text += hpDamageText;
        break;

      case 'MAVERICK CHARM': //HOOLIGANS MAVERICK CHARM
        text = 'ВЕЛИЧНИЙ МАВЕРІК підморгує ' + target.name_davalnyi() + '!\r\n';
        text += 'АТАКА ' + target.name_rodovyi() + ' знизилася.'
        break;

      case 'KIM HEADBUTT': //HOOLIGANS KIM HEADBUTT
        text = 'КІМ врізається головою об ' + target.name_znakhidnyi() + '!\r\n';
        text += hpDamageText;
        break;

      case 'VANCE CANDY': //HOOLIGANS VANCE CANDY
        text = 'ВАНС кидається цукерками!\r\n';
        text += hpDamageText;
        break;

      case 'HOOLIGANS GROUP ATTACK': //THE HOOLIGANS GROUP ATTACK
        text = user.name() + ' викладаються на повну!\r\n';
        text += hpDamageText;
        break;

      //BASIL//
      case 'BASIL ATTACK': //BASIL ATTACK
        text = user.name() + ' сягає нутрощів ' + target.name_rodovyi() + '.\r\n';
        text += hpDamageText;
        break;

      case 'BASIL NOTHING': //BASIL NOTHING
        text = user.name() + ' має червоні очі від плачу.';
        break;

      case 'BASIL PREMPTIVE STRIKE': //BASIL PREMPTIVE STRIKE
        text = user.name() + ' надрізав руку ' + target.name_davalnyi() +'.\r\n';
        text += hpDamageText;
        break;

      //BASIL'S SOMETHING//
      case 'B SOMETHING ATTACK': //BASIL'S SOMETHING ATTACK
        text = user.name() + ' душить ' + target.name_znakhidnyi() + '.\r\n';
        text += hpDamageText;
        break;

      case 'B SOMETHING TAUNT': //BASIL'S SOMETHING TAUNT BASIL
        text = user.name() + ' сягає нутрощів ' + target.name_rodovyi() + '.\r\n';
        break;

      //PLAYER SOMETHING BASIL FIGHT//
      case 'B PLAYER SOMETHING STRESS': //B PLAYER SOMETHING STRESS
        text = user.name() + ' робить дещо з\r\n';
        text += target.name_orudnyi() + '.\r\n';
        text += hpDamageText;
        break;

      case 'B PLAYER SOMETHING HEAL': //B PLAYER SOMETHING HEAL
        text = user.name() + ' просочується у рани ' + target.name_rodovyi() + '.\r\n';
        text += hpDamageText;
        break;

      case 'B OMORI SOMETHING CONSUME EMOTION': //B OMORI SOMETHING CONSUME EMOTION
        text = user.name() + ' поглинає ЕМОЦІЇ ' + target.name_rodovyi() + '.';
        break;

      //CHARLIE//
      case 'CHARLIE RELUCTANT ATTACK': //CHARLIE RELUCTANT ATTACK
        text = user.name() + ' ударяє ' + target.name_znakhidnyi() + '!\r\n';
        text += hpDamageText;
        break;

      case 'CHARLIE NOTHING': //CHARLIE NOTHING
        text = user.name() + ' там стоїть.';
        break;

      case 'CHARLIE LEAVE': //CHARLIE LEAVE
        text = user.name() + ' припиняє боротись.';
        break;

      //ANGEL//
      case 'ANGEL ATTACK': //ANGEL ATTACK
        text = user.name() + ' стрімко вдаряє ногою ' + target.name_znakhidnyi() + '!\r\n';
        text += hpDamageText;
        break;

      case 'ANGEL NOTHING': //ANGEL NOTHING
        text = user.name() + ' робить сальто та позує!';
        break;

      case 'ANGEL QUICK ATTACK': //ANGEL QUICK ATTACK
        text = user.name() + ' телепортується позаду ' + target.name_rodovyi() + '!\r\n';
        text += hpDamageText;
        break;

      case 'ANGEL TEASE': //ANGEL TEASE
        text = user.name() + ' говорить жорстокі речі про ' + target.name_znakhidnyi() + '!';
        break;

      //THE MAVERICK//
      case 'MAVERICK ATTACK': //THE MAVERICK ATTACK
        text = user.name() + ' вдаряє ' + target.name_znakhidnyi() + '!\r\n';
        text += hpDamageText;
        break;

      case 'MAVERICK NOTHING': //THE MAVERICK NOTHING
        text = user.name() + ' починає вихвалятися перед\r\n';
        text += 'своїми шанувальниками!';
        break;

      case 'MAVERICK SMILE': //THE MAVERICK SMILE
        text = user.name() + ' спокусливо усміхається!\r\n';
        text += 'АТАКА ' + target.name_rodovyi() + ' знизилася.';
        break;

      case 'MAVERICK TAUNT': //THE MAVERICK TAUNT
        text = user.name() + ' починає насміхатися над\r\n';
        text += target.name_orudnyi() + '!\r\n';
        text += target.name() + " відчуває ЗЛІСТЬ!"
        break;

      //KIM//
      case 'KIM ATTACK': //KIM ATTACK
        text = user.name() + ' вдаряє ' + target.name_znakhidnyi() + '!\r\n';
        text += hpDamageText;
        break;

      case 'KIM NOTHING': //KIM DO NOTHING
        text = 'У ' + user.name_rodovyi() + ' дзвонить телефон...\r\n';
        text += 'Хтось помилився номером.';
        break;

      case 'KIM SMASH': //KIM SMASH
        text = user.name() + ' хапає ' + target.name_znakhidnyi() + ' за футболку\r\n';
        text += 'та вдаряє кулаком в лице!\r\n';
        text += hpDamageText;
        break;

      case 'KIM TAUNT': //KIM TAUNT
        text = user.name() + ' починає насміхатися над ' + target.name_orudnyi() + '!\r\n';
        text += target.name() + " відчуває СУМ.";
        break;

      //VANCE//
      case 'VANCE ATTACK': //VANCE ATTACK
        text = user.name() + ' вдаряє ' + target.name_znakhidnyi() + '!\r\n';
        text += hpDamageText;
        break;

      case 'VANCE NOTHING': //VANCE NOTHING
        text = user.name() + ' чухає свій живіт.';
        break;

      case 'VANCE CANDY': //VANCE CANDY
        text = user.name() + ' жбурляє старою цукеркою в ' + target.name_znakhidnyi() + '!\r\n';
        text += 'Фу-у-у... Вона смердюча...\r\n';
        text += hpDamageText;
        break;

      case 'VANCE TEASE': //VANCE TEASE
        text = user.name() + ' говорить жорстокі речі про ' + target.name_znakhidnyi() + '!\r\n';
        text += target.name() + " відчуває СУМ."
        break;

      //JACKSON//
      case 'JACKSON WALK SLOWLY': //JACKSON WALK SLOWLY
        text = user.name() + ' повільно підходить...\r\n';
        text += 'Відчуття, ніби не можеш втекти!';
        break;

      case 'JACKSON KILL': //JACKSON AUTO KILL
        text = user.name() + ' ВПІЙМАВ ТЕБЕ!!!\r\n';
        text += 'Твоє життя пронеслося перед очима!';
        break;

      //RECYCLEPATH//
      case 'R PATH ATTACK': //RECYCLEPATH ATTACK
        text = user.name() + ' вдаряє сумкою ' + target.name_znakhidnyi() + '!\r\n';
        text += hpDamageText;
        break;

      case 'R PATH SUMMON MINION': //RECYCLEPATH SUMMON MINION
        text = user.name() + ' кличе послідовників!\r\n';
        text += 'З\'явився СМІТТЄПЕРЕРОБНИЙ ФАНАТИК!';
        break;

      case 'R PATH FLING TRASH': //RECYCLEPATH FLING TRASH
        text = user.name() + ' викидає все своє СМІТТЯ\r\n';
        text += ' у ' + target.name_znakhidnyi() + '!\r\n'
        text += hpDamageText;
        break;

      case 'R PATH GATHER TRASH': //RECYCLEPATH GATHER TRASH
        text = user.name() + ' підбирає трохи СМІТТЯ!';
        break;

    //SOMETHING IN THE CLOSET//
      case 'CLOSET ATTACK': //SOMETHING IN THE CLOSET ATTACK
        text = user.name() + ' волочить ' + target.name_znakhidnyi() + '!\r\n';
        text += hpDamageText;
        break;

      case 'CLOSET NOTHING': //SOMETHING IN THE CLOSET DO NOTHING
        text = user.name() + ' моторошно бурмоче.';
        break;

      case 'CLOSET MAKE AFRAID': //SOMETHING IN THE CLOSET MAKE AFRAID
        text = user.name() + ' знає твій секрет!';
        break;

      case 'CLOSET MAKE WEAK': //SOMETHING IN THE CLOSET MAKE WEAK
        text = user.name() + ' цілить у бажання жити ' + target.name_rodovyi() + '!';
        break;

    //BIG STRONG TREE//
      case 'BST SWAY': //BIG STRONG TREE NOTHING 1
        text = 'Ніжний вітерець дме поміж листочків.';
        break;

      case 'BST NOTHING': //BIG STRONG TREE NOTHING 2
        text = user.name() + ' міцно стоїть, бо\r\n';
        text += 'він дерево.';
        break;

    //DREAMWORLD FEAR EXTRA BATTLES//
    //HEIGHTS//
    case 'DREAM HEIGHTS ATTACK': //DREAM FEAR OF HEIGHTS ATTACK
      text = user.name() + ' вдаряє ' + target.name_znakhidnyi() + '.\r\n';
      text += hpDamageText;
      break;

    case 'DREAM HEIGHTS GRAB': //DREAM FEAR OF HEIGHTS GRAB
      if(target.index() <= unitLowestIndex) {
        text = 'З\'явились руки та хапають усіх!\r\n';
        text += 'У всіх знизилася АТАКА...';
      }

      break;

    case 'DREAM HEIGHTS HANDS': //DREAM FEAR OF HEIGHTS HANDS
      text = 'З\'явилося більше рук та оточують\r\n';
      text += user.name_znakhidnyi() + '.\r\n';
      if(!target._noStateMessage) {text += 'ЗАХИСТ ' + user.name_rodovyi() + ' підвищився!';}
      else {text += parseNoStateChange("ЗАХИСТ", user.name_rodovyi(), "став вище!")}
      break;

    case 'DREAM HEIGHTS SHOVE': //DREAM FEAR OF HEIGHTS SHOVE
      text = user.name() + ' штовхає ' + target.name_znakhidnyi() + '.\r\n';
      text += hpDamageText + '\r\n';
      if(!target._noEffectMessage && target.name() !== "ОМОРІ"){text += target.name() + ' у ЖАХУ.';}
      else {text += parseNoEffectEmotion(target.name(), "відчуває ЖАХ")}
      break;

    case 'DREAM HEIGHTS RELEASE ANGER': //DREAM FEAR OF HEIGHTS RELEASE ANGER
      text = user.name() + ' вивільняє свою ЗЛІСТЬ на всіх!';
      break;

    //SPIDERS//
    case 'DREAM SPIDERS CONSUME': //DREAM FEAR OF SPIDERS CONSUME
      text = user.name() + ' замотує та їсть ' + target.name_znakhidnyi() + '.\r\n';
      text += hpDamageText;
      break;

    //DROWNING//
    case 'DREAM DROWNING SMALL': //DREAM FEAR OF DROWNING SMALL
      text = 'Усі важко дихають.';
      break;

    case 'DREAM DROWNING BIG': //DREAM FEAR OF DROWNING BIG
      text = 'Усі відчувають, ніби от-от втратять свідомість.';
      break;

    // BLACK SPACE EXTRA //
    case 'BS LIAR': // BLACK SPACE LIAR
      text = 'Брехло.';
      break;

    //BACKGROUND ACTORS//
    //BERLY//
      case 'BERLY ATTACK': //BERLY ATTACK
        text = 'БЕРЛІ таранить лобом ' + target.name_znakhidnyi() + '!\r\n';
        text += hpDamageText;
        break;

      case 'BERLY NOTHING 1': //BERLY NOTHING 1
        text = 'БЕРЛІ хоробро ховається в куточку.';
        break;

      case 'BERLY NOTHING 2': //BERLY NOTHING 2
        text = 'БЕРЛІ поправляє окуляри.';
        break;

      //TOYS//
      case 'CAN':  // CAN
        text = user.name() + ' вдаряє ногою БЛЯШАНКУ.';
        break;

      case 'DANDELION':  // DANDELION
        text = user.name() + ' дує на КУЛЬБАБУ.\r\n';
        text += user.name() + ' знову почувається собою.';
        break;

      case 'DYNAMITE':  // DYNAMITE
        text = user.name() + ' кидає ДИНАМІТ!';
        break;

      case 'LIFE JAM':  // LIFE JAM
        text = user.name() + ' намазує ЖИТТЄДЖЕМ на ТОСТ!\r\n';
        text += 'ТОСТ став ' + target.name_orudnyi() + '!';
        break;

      case 'PRESENT':  // PRESENT
        text = target.name() + ' відкриває ПОДАРУНОК.\r\n';
        text += 'Це не те, що ' + target.name() + ' хотів...\r\n';
        if(!target._noEffectMessage){text += target.name() + ' відчуває ЗЛІСТЬ! ';}
        else {text += parseNoEffectEmotion(target.name(), "стає ЗЛІШЕ!")}
        break;

      case 'SILLY STRING':  // DYNAMITE
        if(target.index() <= unitLowestIndex) {
          text = user.name() + ' пшикає ДУРНУВАТОЮ ВЕРВЕЧКОЮ!\r\n';
          text += 'ВУ-У-У-ХУ!! Вечірка!\r\n';
          text += 'Усі відчувають ЩАСТЯ! ';
        }
        break;

      case 'SPARKLER':  // SPARKLER
        text = user.name() + ' запалює БЕНГАЛЬСЬКИЙ ВОГНИК!\r\n';
        text += 'ВУ-У-У-ХУ!! Вечірка!\r\n';
        if(!target._noEffectMessage){text += target.name() + ' відчуває ЩАСТЯ!';}
        else {text += parseNoEffectEmotion(target.name(), "стає ЩАСЛИВІШЕ!")}
        break;

      case 'COFFEE': // COFFEE
        text = user.name() + ' п\'є КАВУ...\r\n';
        text += user.name() + ' почувається дивовижно!';
        break;

      case 'RUBBERBAND': // RUBBERBAND
        text = user.name() + ' ляскає ' + target.name_znakhidnyi() + '!\r\n';
        text += hpDamageText;
        break;

      //OMORI BATTLE//

      case "OMORI ERASES":
        text = user.name() + " стирає ворога.\r\n";
        text += hpDamageText;
        break;

      case "MARI ATTACK":
        text = user.name() + " стирає ворога.\r\n";
        text += target.name() + " у ЖАХУ.\r\n";
        text += hpDamageText;
        break;

      //STATES//
      case 'HAPPY':
        if(!target._noEffectMessage){text = target.name() + ' відчуває ЩАСТЯ!';}
        else {text = parseNoEffectEmotion(target.name(), "стає ЩАСЛИВІШЕ!")}
        break;

      case 'ECSTATIC':
        if(!target._noEffectMessage){text = target.name() + ' в ЕКСТАЗІ!!';}
        else {text = parseNoEffectEmotion(target.name(), "стає ЩАСЛИВІШЕ!")}
        break;

      case 'MANIC':
        if(!target._noEffectMessage){text = target.name() + ' в МАНІЇ!!!';}
        else {text = parseNoEffectEmotion(target.name(), "стає ЩАСЛИВІШЕ!")}
        break;

      case 'SAD':
        if(!target._noEffectMessage){text = target.name() + ' відчуає СУМ.';}
        else {text = parseNoEffectEmotion(target.name(), "стає СУМНІШЕ!")}
        break;

      case 'DEPRESSED':
        if(!target._noEffectMessage){text = target.name() + ' в ЖУРБІ..';}
        else {text = parseNoEffectEmotion(target.name(), "стає СУМНІШЕ!")}
        break;

      case 'MISERABLE':
        if(!target._noEffectMessage){text = target.name() + ' у БЕЗНАДІЇ...';}
        else {text = parseNoEffectEmotion(target.name(), "стає СУМНІШЕ!")}
        break;

      case 'ANGRY':
        if(!target._noEffectMessage){text = target.name() + ' відчуває ЗЛІСТЬ!';}
        else {text = parseNoEffectEmotion(target.name(), "стає ЗЛІШЕ!")}
        break;

      case 'ENRAGED':
        if(!target._noEffectMessage){text = target.name() + ' СКАЖЕНІЄ!!';}
        else {text = parseNoEffectEmotion(target.name(), "стає ЗЛІШЕ!")}
        break;

      case 'FURIOUS':
        if(!target._noEffectMessage){text = target.name() + ' відчуває ЛЮТЬ!!!'}
        else {text = parseNoEffectEmotion(target.name(), "стає ЗЛІШЕ!")}
        break;

      case 'AFRAID':
        if(!target._noEffectMessage){text = target.name() + ' у ЖАХУ!';}
        else {text = parseNoEffectEmotion(target.name(), "ЖАХ")}
        break;

      case 'CANNOT MOVE':
        text = target.name() + ' знерухомлений! ';
        break;

      case 'INFATUATION':
        text = target.name() + ' знерухомлений через любов! ';
        break;

    //SNALEY//
    case 'SNALEY MEGAPHONE': // SNALEY MEGAPHONE
      if(target.index() <= unitLowestIndex) {text = user.name() + ' використовує ГУДОК!\r\n';}
      if(target.isStateAffected(16)) {text += target.name() + ' СКАЖЕНІЄ!!!\r\n'}
      else if(target.isStateAffected(15)) {text += target.name() + ' відчуває ЛЮТЬ!!\r\n'}
      else if(target.isStateAffected(14)) {text += target.name() + ' відчуває ЗЛІСТЬ!\r\n'}
      break;

  }
  // Return Text
  return text;
};
//=============================================================================
// * Display Custom Action Text
//=============================================================================
Window_BattleLog.prototype.displayCustomActionText = function(subject, target, item) {
  // Make Custom Action Text
  var text = this.makeCustomActionText(subject, target, item);
  // If Text Length is more than 0
  if (text.length > 0) {
    if(!!this._multiHitFlag && !!item.isRepeatingSkill) {return;}
    // Get Get
    text = text.split(/\r\n/);
    for (var i = 0; i < text.length; i++) { this.push('addText', text[i]); }
    // Add Wait
    this.push('wait', 15);

  }
  if(!!item.isRepeatingSkill) {this._multiHitFlag = true;}
};
//=============================================================================
// * Display Action
//=============================================================================
Window_BattleLog.prototype.displayAction = function(subject, item) {
  // Return if Item has Custom Battle Log Type
  if (item.meta.BattleLogType) { return; }
  // Run Original Function
  _TDS_.CustomBattleActionText.Window_BattleLog_displayAction.call(this, subject, item);
};
//=============================================================================
// * Display Action Results
//=============================================================================
Window_BattleLog.prototype.displayActionResults = function(subject, target) {
  // Get Item Object
  var item = BattleManager._action._item.object();
  // If Item has custom battle log type
  if (item && item.meta.BattleLogType) {
    // Display Custom Action Text
    this.displayCustomActionText(subject, target, item);
    // Return
  }
  // Run Original Function
  else {
    _TDS_.CustomBattleActionText.Window_BattleLog_displayActionResults.call(this, subject, target);
  }
};

const _old_window_battleLog_displayHpDamage = Window_BattleLog.prototype.displayHpDamage
Window_BattleLog.prototype.displayHpDamage = function(target) {
  let result = target.result();
  if(result.isHit() && result.hpDamage > 0) {
    if(!!result.elementStrong) {
      this.push("addText","... Це була разюча атака!");
      this.push("waitForNewLine");
    }
    else if(!!result.elementWeak) {
      this.push("addText", "... Це була безглузда атака!");
      this.push("waitForNewLine")
    }
  }
  return _old_window_battleLog_displayHpDamage.call(this, target)
};

//=============================================================================
// * CLEAR
//=============================================================================
_TDS_.CustomBattleActionText.Window_BattleLog_endAction= Window_BattleLog.prototype.endAction;
Window_BattleLog.prototype.endAction = function() {
  _TDS_.CustomBattleActionText.Window_BattleLog_endAction.call(this);
  this._multiHitFlag = false;
};

//=============================================================================
// * DISPLAY ADDED STATES
//=============================================================================
